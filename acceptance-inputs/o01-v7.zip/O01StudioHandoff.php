<?php
declare(strict_types=1);
/** Uninstalled source candidate. No routes, hooks, publication, or payment authority.
 * Inject server-owned authentication/CSRF/ownership and immutable G1 storage adapters.
 * The store must atomically bind request_key to owner/project/input, insert once,
 * and return read-back bytes. Never bind these callbacks from request data.
 */
final class O01StudioHandoff {
    public static function receive(array $package, int $projectId, string $requestKey,
        callable $authenticate, callable $ownsProject, callable $saveImmutable): array {
        $deny = static fn(string $reason): array => ['result'=>'DENIED','reason'=>$reason,'published'=>false];
        try {
            // Authentication callback includes request authentication and CSRF verification.
            $ownerId = $authenticate();
            if (!is_int($ownerId) || $ownerId < 1) return $deny('authentication_required');
            if ($projectId < 1 || $ownsProject($projectId, $ownerId) !== true) return $deny('ownership_required');
            if (!preg_match('/\A[a-zA-Z0-9_.-]{16,120}\z/D', $requestKey)) return $deny('invalid_request_key');
            $keys = array_keys($package); sort($keys);
            $expected = ['schema','authority','publication_authorized','revision','draft','approved_full_html','full_html_sha256']; sort($expected);
            if ($keys !== $expected || $package['schema'] !== 'peoplerun.o01.local_full_html_approval.v1'
                || $package['authority'] !== 'LOCAL_ONLY_NOT_HOST_RECEIPT'
                || $package['publication_authorized'] !== false
                || !is_int($package['revision']) || $package['revision'] < 1
                || !is_array($package['draft'])) return $deny('invalid_package');
            $html = $package['approved_full_html']; $sha = $package['full_html_sha256'];
            if (!is_string($html) || $html === '' || strlen($html) > 250000
                || strpos($html, "\0") !== false || preg_match('//u', $html) !== 1
                || !is_string($sha) || !preg_match('/\A[a-f0-9]{64}\z/D', $sha)
                || !hash_equals($sha, hash('sha256', $html))) return $deny('content_mismatch');
            // Local approval is untrusted intake, never consent/payment/publication evidence.
            $input = ['owner_id'=>$ownerId,'project_id'=>$projectId,'html'=>$html,
                'content_sha256'=>$sha,'request_key'=>$requestKey];
            $stored = $saveImmutable($input);
            if (!is_array($stored) || !is_int($stored['revision_id']??null) || $stored['revision_id'] < 1
                || ($stored['owner_id']??null) !== $ownerId || ($stored['project_id']??null) !== $projectId
                || ($stored['html']??null) !== $html || ($stored['content_sha256']??null) !== $sha)
                return $deny('immutable_storage_not_verified');
            return ['result'=>'REVISION_SAVED_CANDIDATE','owner_id'=>$ownerId,'project_id'=>$projectId,
                'revision_id'=>$stored['revision_id'],'content_sha256'=>$sha,
                'approval_verified'=>false,'payment_verified'=>false,'publication_authorized'=>false,'published'=>false];
        } catch (Throwable $e) { return $deny('dependency_failed'); }
    }
}
