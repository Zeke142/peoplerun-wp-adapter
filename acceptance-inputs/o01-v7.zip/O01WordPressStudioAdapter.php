<?php
declare(strict_types=1);
require_once __DIR__.'/O01StudioHandoff.php';
/** Uninstalled candidate. Deliberately registers no hook, route or publication action.
 * Cookie-authenticated REST requests only; no identity or callbacks come from input.
 */
final class O01WordPressStudioAdapter {
    public static function receive(array $package, int $projectId, int $expectedVersion,
        string $requestKey, WP_REST_Request $request): array {
        return O01StudioHandoff::receive($package, $projectId, $requestKey,
            static function () use ($request): int {
                if ($request->get_method() !== 'POST' || !is_ssl() || !is_user_logged_in()) return 0;
                $nonce = $request->get_header('X-WP-Nonce');
                if (!is_string($nonce) || $nonce === '' || strlen($nonce) > 128) return 0;
                $verified = wp_verify_nonce($nonce, 'wp_rest');
                if ($verified !== 1 && $verified !== 2) return 0;
                $owner = get_current_user_id();
                return is_int($owner) && $owner > 0 ? $owner : 0;
            },
            static fn(int $project, int $owner): bool =>
                function_exists('pr_iw_g1_v2_owner') && pr_iw_g1_v2_owner($project, $owner),
            static function (array $input) use ($expectedVersion): array {
                if ($expectedVersion < 0 || $expectedVersion === PHP_INT_MAX
                    || !function_exists('pr_iw_g1_v2_add_revision')
                    || !function_exists('pr_iw_g1_v2_read_revision')) {
                    throw new RuntimeException('revision_dependency_unavailable');
                }
                $saved = pr_iw_g1_v2_add_revision($input['project_id'], $input['owner_id'],
                    $input['html'], $expectedVersion, $input['request_key']);
                if (is_wp_error($saved) || !is_array($saved)
                    || !is_int($saved['revision_id'] ?? null) || $saved['revision_id'] < 1) {
                    throw new RuntimeException('revision_write_failed');
                }
                $id = $saved['revision_id'];
                $read = pr_iw_g1_v2_read_revision($input['project_id'], $id, $input['owner_id']);
                // G1 replay returns an ID before comparing payload or expected version.
                // Read the actual revision on EVERY path, including replay.
                $number = get_post_meta($id, '_pr_iw_revision_number', true);
                if (is_wp_error($read) || !is_array($read)
                    || ($read['revision_id'] ?? null) !== $id
                    || ($read['html'] ?? null) !== $input['html']
                    || ($read['content_sha256'] ?? null) !== $input['content_sha256']
                    || !hash_equals($input['content_sha256'], hash('sha256', $read['html']))
                    || !is_string($number) || $number !== (string)($expectedVersion + 1)) {
                    throw new RuntimeException('revision_readback_conflict');
                }
                return $input + ['revision_id'=>$id];
            });
    }
}
