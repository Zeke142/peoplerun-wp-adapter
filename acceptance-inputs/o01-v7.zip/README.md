# O01 real WordPress acceptance harness — source candidate

Built October 30, 2026. NOT EXECUTED against WordPress/MySQL.

This adds real WordPress password authentication, nonce verification, G1 ownership, MySQL-backed private revision writes and direct exact-byte database readback. It reuses the saved adapter and G1 snapshot unchanged. No public HTTP route is registered.

Requires a disposable local WordPress installation with DB_NAME=o01_ephemeral, table prefix o01_acceptance_, loopback DB host, and loopback home URL. Never point it at SiteGround or production. The script creates and deletes its own temporary users and posts. Failed writes may leave data; discard the entire disposable database after testing.

Run only after independently preparing that disposable installation:

```sh
O01_DISPOSABLE_ACCEPTANCE=YES O01_WP_ROOT=/absolute/local/wordpress php acceptance.php
```

Current environment has no native PHP, MySQL or Docker executable, so real integration results are UNVERIFIED. PHP syntax validation is a separate check. Full HTTP cookie/session rejection and acceptance, actual HTTPS transport, execution of concurrent-worker checks, restart durability, publishing, payment and expiry remain outstanding. The script uses wp_signon and wp_set_current_user in process; it does not establish HTTP cookie authentication. $_SERVER HTTPS is set solely to exercise the adapter guard, not prove TLS.

Next: prepare the disposable runtime and execute this harness; then add actual HTTP cookie/nonce and concurrent-worker acceptance. Do not count these proposed checks as passed until run.

## Added multi-process concurrency candidate

`concurrency.php` starts two native PHP workers against the disposable database, waits for both to be ready, then releases them together. Same request keys must return the same revision. Different keys with the same starting version must produce one success and one rejection. Both scenarios require exactly one stored revision and project version 1 by direct database query. Workers use real G1 MySQL locks and adapter readback; WordPress current user and nonce are set in process. This does not test HTTP cookie authentication or TLS.

```sh
O01_DISPOSABLE_ACCEPTANCE=YES O01_WP_ROOT=/absolute/local/wordpress php concurrency.php
```

Status: concurrency source written, NOT EXECUTED. Requires native PHP process spawning and the same isolated WordPress/MySQL setup. It registers no HTTP route and makes no production change. Discard the disposable database after testing, even if cleanup fails. The runtime is still missing here; do not report race outcomes as observed.

## Observed validation

PHP 8.3 WebAssembly token_get_all with TOKEN_PARSE accepted both acceptance.php and concurrency.php on October 30, 2026. This is syntax validation only; no WordPress/MySQL behavior or subprocess race was executed.

## Saved stop — HTTP session source candidate

Owner requested save state on October 30, 2026. Stop further build after checkpointing.

Added source only:
- http-local-plugin.php: disposable loopback-only WordPress test route and authenticated AJAX nonce retrieval. Requires environment opt-in, exact disposable database name/table prefix, and loopback home URL/database host. No route has been installed.
- http-fixture.php: CLI setup creates two disposable WordPress users and one G1 project. Emits local test credentials to stdout; redirect only to a private local fixture file. Never package or upload that generated fixture. This setup has NOT been run.
- http-acceptance.py: HTTPS client with actual cookie jar and certificate validation. Rejects non-loopback roots and redirects outside the selected origin. Tests anonymous access, wrong password, real cookie/nonce acquisition, invalid/missing nonce, save, replay, altered replay, stale version, and another owner's request. No insecure TLS bypass.

Validation observed: all four PHP files pass PHP 8.3 WebAssembly parser validation; Python py_compile passes for http-acceptance.py. These prove syntax only. No WordPress, MySQL, HTTPS session, fixture creation, or concurrent-worker run has occurred.

Resume: review these unexecuted harness candidates, prepare disposable native PHP + WordPress + MySQL with DB_NAME=o01_ephemeral, prefix o01_acceptance_, loopback home/DB, and real local HTTPS. Then install the test plugin ONLY within that disposable instance, with O01_DISPOSABLE_ACCEPTANCE=YES and O01_HARNESS_ROOT pointing at this source directory. Do not use SiteGround. The runtime and HTTPS launcher are not yet built by this package.

After setting up the disposable environment, generate a new local fixture with restrictive permissions:

```sh
umask 077
O01_DISPOSABLE_ACCEPTANCE=YES O01_HARNESS_ROOT=/absolute/path/to/harness O01_WP_ROOT=/absolute/local/wordpress php http-fixture.php setup > /private/local/http-fixture.json
python3 http-acceptance.py --base-url https://localhost:8443 --ca-file /private/local/test-ca.pem --fixture /private/local/http-fixture.json
```

The illustrative paths require the actual local setup; these commands have not been executed. Run acceptance.php and concurrency.php separately for direct database readback and multiworker races. HTTP fixture data must be fresh for each run because the suite advances its project version. Discard the entire disposable database and private fixture afterward. Do not infer zero database side effects from a denied request. Production, customer payment, renderer security, identical published output and enforced expiration remain unproven.


## Text-session extension — disposable HTTPS launcher

Added run-http-local.sh, local-tls-proxy.py and test-local-tls-proxy.py. The launcher requires an already prepared disposable WordPress/MySQL installation, exact home_url https://127.0.0.1:8443, DB_NAME o01_ephemeral, prefix o01_acceptance_ and loopback DB. It refuses occupied ports and existing test-plugin/router paths. It runs the in-process and concurrency suites before installing the disposable HTTP plugin, creates a temporary private certificate and fixture, runs real HTTPS cookie tests and removes its own plugin/router/TLS files and terminates its processes afterward. It does not drop the database: discard the complete disposable database after use. No SiteGround or production target is supported. Never upload runtime fixture credentials. Native PHP, MySQL and WordPress remain external prerequisites; the launcher does not install them.

Observed this text session: bash -n PASS; Python compile PASS; 4/4 local TLS transport smoke tests PASS (body+nonce forwarding, secure cookie propagation, untrusted certificate rejection, oversized request rejection). These use a tiny local HTTP probe backend, NOT WordPress/MySQL. The full launcher exits with Missing runtime: php before any installation. apt-get update failed because the environment cannot switch package-manager user/groups; no privilege bypass or global installation was attempted afterward. No real integration pass is claimed. Existing repository workflow was inspected and only runs synthetic delivery acceptance; dispatching it would not execute these new suites.

Run on a separately admitted native environment:

```sh
O01_DISPOSABLE_ACCEPTANCE=YES O01_WP_ROOT=/absolute/disposable/wordpress bash run-http-local.sh
```

The environment must already contain native PHP with MySQL support, Python 3, OpenSSL, WordPress and a disposable database. Real CLI, multiworker, HTTPS session acceptance remains UNEXECUTED. This launcher is source-reviewed and transport-smoke-tested only.


## Latest voice build — denied HTTP writes, October 30, 2026

This section supersedes the earlier source-only review's NOT BUILT status for database invariants ONLY. Expired/revoked session and expired/cross-session nonce additions remain NOT BUILT. The existing two-project queue is unchanged: O01 first; System Builder v0.2.4 hosted replacement second with separate authorization.

Added http-db-snapshot.php, a private CLI observer restricted to the disposable database, table prefix, loopback host, opt-in and exact https://127.0.0.1:8443 home. It queries raw project/child post rows and their metadata, bypassing object caches, and returns revision count, project version and a SHA-256 fingerprint of the ordered rows. Content and credentials are not emitted. No HTTP observer route is created. This covers the selected project subtree; it is not a database-wide no-side-effects claim.

http-acceptance.py now calls that observer before and after all six existing denied writes: anonymous, invalid nonce, missing nonce, changed replay, stale version, and another owner. Any fingerprint/count/version difference aborts. Observer failure or malformed output also aborts. The cross-owner case uses a fresh request key and current expected version rather than a stale version, so it is otherwise eligible to write.

Observed verification: Python syntax PASS. Two synthetic client-orchestration cases PASS: all six denials request paired snapshots; an injected changed snapshot stops the run. These are simulations of orchestration only, NOT WordPress, authentication, database-query or security acceptance. New PHP observer syntax and execution remain UNVERIFIED because native PHP is unavailable. Prior PHP syntax results apply to earlier source, not this new file. No fixture, deployment, workflow dispatch or production change occurred.

Exact text-session action: recover this package, syntax-check the new PHP observer in a native PHP environment, review raw database snapshot coverage, build the remaining session-expiry/revocation/nonce cases, then execute all suites in the existing disposable runtime plan. Use run-http-local.sh after independently preparing native PHP with MySQL support, WordPress, Python/OpenSSL and database o01_ephemeral with prefix o01_acceptance_. No SiteGround or production installation is authorized. Keep fixtures private and discard disposable database after the run. Real integration remains UNRUN.

Base package SHA-256 before this build: cc0b425346d82018ed5b4526fcc17bded314ddc7da6f344faa9e0fa5f1cd4dd2. Same Library identity libfile_7212fdb21b3c8191a8c5e15871069f57. Current checksum manifest covers all shipped source files except itself. No product closure claimed.


## Latest voice build — server-revoked session candidate

Supersedes NOT BUILT for the revoked-session case only. Added http-revoke-fixture-session.php: CLI-only, opt-in, exact disposable DB/prefix/home restrictions; requires a matching fixture-owner ID and username of form o01_http_owner_<16 lowercase hex characters>. Requires at least one existing session, destroys that fixture owner's sessions and verifies none remain. No credentials are passed through command arguments or emitted. No HTTP control route is created.

The HTTP suite now retains its original owner cookie jar and nonce, invokes private fixture revocation after existing write tests, and retries a fresh write key at version 1. It expects authentication rejection (401 authentication_required or 403 rest_cookie_invalid_nonce) and unchanged project snapshots. Revocation is server-side; deleting a client cookie is not used as substitute proof. This fixture invalidates all sessions of that disposable owner, not other users. It does not prove natural expiration, session-specific selective revocation or production behavior.

Observed: Python syntax PASS. Three synthetic cases PASS: stdin-only identity transport; incomplete revocation confirmation rejected; old cookie session and nonce replayed using a fresh key/current version. No native PHP syntax or WordPress/MySQL execution was available. No production change, deployment or real session revocation performed.

WordPress API references checked: https://developer.wordpress.org/reference/classes/wp_session_tokens/ and https://developer.wordpress.org/reference/classes/wp_session_tokens/destroy_all/ . These explain the API; source simulation does not establish live behavior.

Updated exact text Next: recover latest package, native PHP syntax-check BOTH new CLI helpers, prepare the independently available disposable runtime, then execute the suites and preserve redacted evidence. Remaining source gaps: genuine natural cookie expiry, expired nonce, cross-user and cross-session nonce cases. Prior source review/checkpoint statements NOT BUILT are historical where superseded here. Existing System Builder update remains separately pending. Base ZIP for this increment: f619d0382bed4f66151583283c9a82176bf1b8fe9b5dbb61f8a6531e35293132 (Library version 4).


## Latest voice continuation — cross-user and cross-session nonce candidates

Added two source cases to http-acceptance.py: original owner cookie plus another user's REST nonce; original owner cookie plus a distinct nonce obtained through a separate fresh login of that same owner. Both use new request keys, expected version 1, explicit WordPress invalid-nonce response assertions and paired private project snapshots. The second login must return a distinct nonce or the suite stops without claiming the case was exercised. These run before the existing fixture-owner session revocation case.

Observed: Python syntax PASS. Three synthetic orchestration checks PASS: cross-user pairing, cross-session pairing, and paired snapshots for all nine denied HTTP writes. No real nonce rejection, cookie/session behavior, PHP syntax or database execution was observed. Source API context is the WordPress documentation already linked above; real results remain UNRUN.

Supersedes prior NOT BUILT status for cross-user and cross-session nonce source only. Natural cookie expiry and expired-nonce cases still need implementation. Text pickup: native PHP syntax-check the two new private CLI helpers, then run the current suites in the independently prepared disposable environment, preserving redacted evidence. No new screen action is needed during voice. No deployment, public control endpoint, production change, spending or closure. Previous package SHA-256 a27eb50b00cf67b5c7ced89491832067f2f2df7df5c422bc4c6252dbb1f9b89c, Library version 5.


## Current owner-requested stop

See SAVE_STATE.md for authoritative latest source status and exact text Next. Expiration source is written, Python syntax checked only; additional simulations, PHP parsing and real integration remain unrun. Work stopped at owner request.
