# O01 — owner-requested stop, October 30, 2026

Owner requested save state and hang up. Further build is stopped after preservation.

Latest source: expiration cases added to http-acceptance.py and new private CLI helper http-expiry-fixture.php. Python syntax PASS. No expiration orchestration simulations were run before this stop. New PHP syntax, fixture generation, actual nonce/cookie expiration rejection and database execution remain UNVERIFIED/UNRUN. Do not apply earlier simulation passes to these new cases.

Expiry design: validates original fixture-owner cookie/session, generates an out-of-window nonce using the actual session token and an older WordPress nonce tick, and signs a cookie whose embedded expiration is over two hours in the past, beyond POST/AJAX grace. The candidate verifies controls privately before returning credentials to the local client. The HTTP client delivers the expired signed cookie rather than silently dropping it because of client cookie-jar expiry. No global clock change, shortened production lifetime, public fixture route or real production credential is used. These are constructed signed expired fixtures, NOT credentials observed aging naturally over time.

Prior saved source retained: database invariants around denied HTTP writes; server-side fixture-owner session revocation; cross-user and same-user cross-session nonce tests. Prior synthetic verification: 2 database orchestration cases, 3 revocation-control/orchestration cases and 3 cross-user/session orchestration cases. These are separate local simulations; no WordPress security/integration PASS is established. New expiry cases bring planned rejected-write snapshot coverage to eleven cases; the expanded suite has NOT been run.

Exact text Next: recover latest package by its Library identity libfile_7212fdb21b3c8191a8c5e15871069f57 and saved current hash in the parent checkpoint. Review expiry helper and client transport together; validate all three new PHP helpers (http-db-snapshot.php, http-revoke-fixture-session.php, http-expiry-fixture.php) with native PHP syntax checks; exercise the new expiry orchestration and resolve any failures. Then prepare independently available disposable native PHP/MySQL/WordPress environment and run all three suites via run-http-local.sh. Environment: DB_NAME=o01_ephemeral, prefix o01_acceptance_, loopback DB, exact home https://127.0.0.1:8443. PHP/MySQL/Docker were unavailable in this session. Do not use SiteGround or production as workaround. Keep generated runtime fixtures private; discard database/private credentials after testing. No external workflow/repository writes, spending or deployment authorized by this checkpoint.

The same two-project text queue remains: (1) O01 real integration and source verification described here; (2) System Builder v0.2.4 restore-feedback fix, 32 prior local checks PASS, not deployed, separate explicit SiteGround sign-in/update authorization pending. Preserve owner JSON, deployed v0.2.3 and prior device acceptance. No new approval granted by save-state instruction.

O01 product finish line still requires preview -> approval/payment bound to immutable revision -> identical published output -> enforced duration. Test-source progress does not complete that product or permit customer discovery. No host receipt or closure is claimed.

Source references consulted for expiry fixture construction:
- https://developer.wordpress.org/reference/functions/wp_verify_nonce/
- https://developer.wordpress.org/reference/functions/wp_validate_auth_cookie/

Previous package hash (Library version 6): 7572c2abaea460942ee47b54ce062c5b98bdb4f752d35780de5dacbc20853527.
