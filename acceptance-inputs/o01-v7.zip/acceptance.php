<?php
declare(strict_types=1);
// CLI only, disposable local database only. No HTTP route is installed.
if (PHP_SAPI !== 'cli' || getenv('O01_DISPOSABLE_ACCEPTANCE') !== 'YES') {
    fwrite(STDERR, "Disposable acceptance opt-in required\n"); exit(2);
}
$root = getenv('O01_WP_ROOT');
if (!$root || !is_file($root.'/wp-load.php')) { throw new RuntimeException('Local WordPress root required'); }
require $root.'/wp-load.php';
global $wpdb;
if (!in_array(DB_HOST, ['127.0.0.1','127.0.0.1:3306','localhost'], true)
    || DB_NAME !== 'o01_ephemeral' || $wpdb->prefix !== 'o01_acceptance_'
    || !in_array(parse_url(home_url(), PHP_URL_HOST), ['127.0.0.1','localhost'], true)) {
    throw new RuntimeException('Refusing non-disposable WordPress configuration');
}
if (function_exists('pr_iw_g1_v2_add_revision')) { throw new RuntimeException('Unexpected preinstalled G1'); }
require __DIR__.'/g1-host-source.php';
require __DIR__.'/O01WordPressStudioAdapter.php';
foreach (['pr_iw_project','pr_iw_revision'] as $type) {
    register_post_type($type, ['public'=>false,'show_in_rest'=>false]);
}
$users=[]; $posts=[]; $count=0;
$check=static function(bool $ok,string $label) use (&$count):void {
    if (!$ok) { throw new RuntimeException($label); }
    ++$count; echo "PASS $label\n";
};
try {
    $tag=bin2hex(random_bytes(8)); $password=bin2hex(random_bytes(24));
    foreach (['owner','other'] as $role) {
        $id=wp_create_user('o01_'.$role.'_'.$tag,$password);
        if (is_wp_error($id)) { throw new RuntimeException('User creation failed'); }
        $users[$role]=(int)$id;
    }
    $bad=wp_signon(['user_login'=>'o01_owner_'.$tag,'user_password'=>$password.'wrong'],false);
    $check(is_wp_error($bad),'real WordPress password rejection');
    $login=wp_signon(['user_login'=>'o01_owner_'.$tag,'user_password'=>$password],false);
    $check($login instanceof WP_User && $login->ID===$users['owner'],'real WordPress password acceptance');
    wp_set_current_user($users['owner']);
    $project=pr_iw_g1_v2_create_project($users['owner'],'Acceptance '.$tag,'project_'.$tag);
    if (is_wp_error($project)) { throw new RuntimeException('G1 project creation failed'); }
    $pid=$posts[]=$project['project_id'];
    // Exercise adapter SSL requirement in-process; this is NOT a TLS transport test.
    $_SERVER['HTTPS']='on';
    $html="<!doctype html>\r\n<html><head><style>body{color:#123}</style></head><body>Eric’s café</body></html>\n";
    $package=['schema'=>'peoplerun.o01.local_full_html_approval.v1','authority'=>'LOCAL_ONLY_NOT_HOST_RECEIPT',
        'publication_authorized'=>false,'revision'=>1,'draft'=>[],
        'approved_full_html'=>$html,'full_html_sha256'=>hash('sha256',$html)];
    $request=new WP_REST_Request('POST','/uninstalled-local-test');
    $run=static fn(array $p,string $key,int $v=0):array=>O01WordPressStudioAdapter::receive($p,$pid,$v,$key,$request);
    $request->set_header('X-WP-Nonce','invalid');
    $check($run($package,'request_'.$tag)['reason']==='authentication_required','real nonce rejection');
    $request->set_header('X-WP-Nonce',wp_create_nonce('wp_rest'));
    $saved=$run($package,'request_'.$tag);
    $check(($saved['result']??'')==='REVISION_SAVED_CANDIDATE','real G1 database revision saved');
    $rid=$posts[]=$saved['revision_id'];
    clean_post_cache($rid);
    $raw=$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id=%d AND meta_key=%s",$rid,'_pr_iw_html_b64'));
    $check(is_string($raw) && base64_decode($raw,true)===$html,'direct database exact-byte readback');
    $check(($run($package,'request_'.$tag)['revision_id']??0)===$rid,'same-key replay returns original revision');
    $changed=$package; $changed['approved_full_html'].='changed'; $changed['full_html_sha256']=hash('sha256',$changed['approved_full_html']);
    $check(($run($changed,'request_'.$tag)['result']??'')==='DENIED','changed-content replay rejected');
    $check(($run($package,'new_request_'.$tag)['result']??'')==='DENIED','stale expected version rejected');
    wp_set_current_user($users['other']);
    $request->set_header('X-WP-Nonce',wp_create_nonce('wp_rest'));
    $check(($run($package,'other_request_'.$tag)['reason']??'')==='ownership_required','real project ownership rejection');
    wp_set_current_user(0);
    $check(($run($package,'anon_request_'.$tag)['reason']??'')==='authentication_required','anonymous rejection');
    $check($saved['approval_verified']===false && $saved['payment_verified']===false && $saved['published']===false,'no approval payment or publication authority granted');
    echo "$count real WordPress in-process checks passed\n";
} finally {
    wp_set_current_user(0);
    foreach (array_reverse($posts) as $id) { wp_delete_post($id,true); }
    require_once ABSPATH.'wp-admin/includes/user.php';
    foreach ($users as $id) { wp_delete_user($id); }
}
