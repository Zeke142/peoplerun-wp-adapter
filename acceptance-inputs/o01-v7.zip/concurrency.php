<?php
declare(strict_types=1);
if (PHP_SAPI!=='cli' || getenv('O01_DISPOSABLE_ACCEPTANCE')!=='YES') { exit(2); }
$root=getenv('O01_WP_ROOT');
if (!$root || !is_file($root.'/wp-load.php')) { throw new RuntimeException('Local WordPress root required'); }
require $root.'/wp-load.php';
global $wpdb;
if (!in_array(DB_HOST,['localhost','127.0.0.1','127.0.0.1:3306'],true)
    || DB_NAME!=='o01_ephemeral' || $wpdb->prefix!=='o01_acceptance_'
    || !in_array(parse_url(home_url(),PHP_URL_HOST),['localhost','127.0.0.1'],true)) {
    throw new RuntimeException('Refusing non-disposable configuration');
}
if (function_exists('pr_iw_g1_v2_add_revision')) { throw new RuntimeException('Unexpected installed G1'); }
require __DIR__.'/g1-host-source.php';
require __DIR__.'/O01WordPressStudioAdapter.php';
foreach(['pr_iw_project','pr_iw_revision'] as $type) { register_post_type($type,['public'=>false,'show_in_rest'=>false]); }
function receive_revision(int $pid,string $key):array {
    $_SERVER['HTTPS']='on'; // In-process guard only; no TLS or cookie claim.
    $html="<!doctype html>\r\n<html><body>Concurrent café</body></html>\n";
    $p=['schema'=>'peoplerun.o01.local_full_html_approval.v1','authority'=>'LOCAL_ONLY_NOT_HOST_RECEIPT',
        'publication_authorized'=>false,'revision'=>1,'draft'=>[],
        'approved_full_html'=>$html,'full_html_sha256'=>hash('sha256',$html)];
    $request=new WP_REST_Request('POST','/uninstalled-local-concurrency');
    $request->set_header('X-WP-Nonce',wp_create_nonce('wp_rest'));
    return O01WordPressStudioAdapter::receive($p,$pid,0,$key,$request);
}
if (($argv[1]??'')==='worker') {
    [$script,$mode,$uid,$pid,$key,$barrier,$slot]=$argv;
    wp_set_current_user((int)$uid);
    touch($barrier.'/ready-'.$slot);
    $deadline=microtime(true)+15;
    while (!is_file($barrier.'/go')) {
        if(microtime(true)>$deadline) { throw new RuntimeException('Barrier timeout'); }
        usleep(10000);
    }
    echo json_encode(receive_revision((int)$pid,$key),JSON_THROW_ON_ERROR)."\n";
    exit;
}
if (!function_exists('proc_open')) { throw new RuntimeException('Native process support required'); }
$projects=[]; $uid=0; $dirs=[]; $tag=bin2hex(random_bytes(8));
try {
    $created=wp_create_user('o01_concurrent_'.$tag,bin2hex(random_bytes(24)));
    if(is_wp_error($created)) { throw new RuntimeException('User creation failed'); }
    $uid=(int)$created; wp_set_current_user($uid);
    foreach(['same-key','different-keys'] as $scenario) {
        $p=pr_iw_g1_v2_create_project($uid,'Concurrency '.$scenario,'project_'.$scenario.'_'.$tag);
        if(is_wp_error($p)) { throw new RuntimeException('Project creation failed'); }
        $pid=$projects[]=(int)$p['project_id'];
        $dir=sys_get_temp_dir().'/o01-race-'.bin2hex(random_bytes(12));
        if(!mkdir($dir,0700)) { throw new RuntimeException('Barrier directory failed'); }
        $dirs[]=$dir; $children=[];
        try {
            for($i=0;$i<2;$i++) {
                $key='request_'.$tag.($scenario==='same-key'?'':'_'.$i);
                $pipes=[];
                $proc=proc_open([PHP_BINARY,__FILE__,'worker',(string)$uid,(string)$pid,$key,$dir,(string)$i],
                    [0=>['pipe','r'],1=>['file',$dir.'/out-'.$i,'w'],2=>['file',$dir.'/err-'.$i,'w']],$pipes);
                if(!is_resource($proc)) { throw new RuntimeException('Worker spawn failed'); }
                fclose($pipes[0]); $children[]=$proc;
            }
            $deadline=microtime(true)+15;
            while(!is_file($dir.'/ready-0') || !is_file($dir.'/ready-1')) {
                if(microtime(true)>$deadline) { throw new RuntimeException('Worker readiness timeout'); }
                usleep(10000);
            }
            touch($dir.'/go');
            $results=[];
            foreach($children as $i=>$proc) {
                do {
                    $status=proc_get_status($proc);
                    if(!$status['running']) { break; }
                    if(microtime(true)>$deadline) { throw new RuntimeException('Worker execution timeout'); }
                    usleep(10000);
                } while(true);
                if($status['exitcode']!==0) { throw new RuntimeException('Worker failed; inspect local error log'); }
                $results[]=json_decode(trim((string)file_get_contents($dir.'/out-'.$i)),true,512,JSON_THROW_ON_ERROR);
            }
            $success=array_values(array_filter($results,static fn($r)=>($r['result']??'')==='REVISION_SAVED_CANDIDATE'));
            $denied=array_values(array_filter($results,static fn($r)=>($r['result']??'')==='DENIED'));
            $rows=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_parent=%d AND post_type=%s",$pid,'pr_iw_revision'));
            $version=$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id=%d AND meta_key=%s",$pid,'_pr_iw_version'));
            if($rows!==1 || $version!=='1') { throw new RuntimeException('Duplicate revision or version inconsistency'); }
            if($scenario==='same-key') {
                if(count($success)!==2 || $success[0]['revision_id']!==$success[1]['revision_id']) {
                    throw new RuntimeException('Same-key replay failed');
                }
            } elseif(count($success)!==1 || count($denied)!==1) { throw new RuntimeException('Version race did not reject one request'); }
            echo "PASS $scenario: one stored revision; version 1; expected worker outcomes\n";
        } finally {
            foreach($children as $proc) { if(is_resource($proc)) { $s=proc_get_status($proc); if($s['running'])proc_terminate($proc); proc_close($proc); } }
        }
    }
    echo "Two real multi-process scenarios passed; HTTP sessions and TLS not tested\n";
} finally {
    foreach($projects as $pid) {
        $ids=$wpdb->get_col($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_parent=%d AND post_type=%s",$pid,'pr_iw_revision'));
        foreach($ids as $id) { wp_delete_post((int)$id,true); }
        wp_delete_post($pid,true);
    }
    wp_set_current_user(0);
    require_once ABSPATH.'wp-admin/includes/user.php';
    if($uid)wp_delete_user($uid);
    foreach($dirs as $dir) { foreach(glob($dir.'/*')?:[] as $f)unlink($f); rmdir($dir); }
}
