#!/usr/bin/env python3
"""Real loopback HTTPS WordPress cookie/nonce tests. No mocked authentication."""
import argparse
import copy
import hashlib
import http.cookiejar
import json
import ssl
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def origin(url):
    p = urllib.parse.urlsplit(url)
    return p.scheme, p.hostname, p.port or 443


def validate_base(url):
    p = urllib.parse.urlsplit(url)
    if (p.scheme != 'https' or p.hostname not in ('localhost', '127.0.0.1')
            or p.username or p.password or p.query or p.fragment or p.path not in ('', '/')):
        raise ValueError('Only a disposable loopback HTTPS root is allowed')
    return url.rstrip('/')


class LocalRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, base):
        self.allowed_origin = origin(base)

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if origin(newurl) != self.allowed_origin:
            raise RuntimeError('Refusing redirect outside the selected local HTTPS origin')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def session(base, context):
    return urllib.request.build_opener(LocalRedirect(base),
        urllib.request.HTTPSHandler(context=context),
        urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))


def request(opener, url, data=None, headers=None):
    try:
        with opener.open(urllib.request.Request(url, data=data, headers=headers or {}), timeout=15) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def login(opener, base, credentials, password_override=None):
    request(opener, base + '/wp-login.php')
    fields = {'log': credentials['username'],
              'pwd': credentials['password'] if password_override is None else password_override,
              'wp-submit': 'Log In', 'testcookie': '1',
              'redirect_to': base + '/wp-admin/admin-ajax.php?action=o01_acceptance_nonce'}
    request(opener, base + '/wp-login.php', urllib.parse.urlencode(fields).encode(),
            {'Content-Type': 'application/x-www-form-urlencoded'})
    status, body = request(opener, base + '/wp-admin/admin-ajax.php?action=o01_acceptance_nonce')
    if status != 200:
        return None
    payload = json.loads(body)
    return payload.get('data', {}).get('nonce') if payload.get('success') is True else None


def database_snapshot(project_id):
    script = Path(__file__).with_name('http-db-snapshot.php')
    result = subprocess.run(['php', str(script)],
        input=json.dumps({'project_id': project_id}), text=True,
        capture_output=True, check=True, timeout=30)
    value = json.loads(result.stdout)
    if (value.get('schema') != 'o01.private-db-snapshot.v1'
            or value.get('project_id') != project_id
            or type(value.get('revision_count')) is not int
            or value['revision_count'] < 0
            or not isinstance(value.get('version'), str)
            or not isinstance(value.get('rows_sha256'), str)
            or len(value['rows_sha256']) != 64
            or any(c not in '0123456789abcdef' for c in value['rows_sha256'])):
        raise ValueError('Invalid private database snapshot')
    return value


def revoke_fixture_session(owner):
    result = subprocess.run(['php', str(Path(__file__).with_name('http-revoke-fixture-session.php'))],
        input=json.dumps({'user_id': owner['user_id'], 'username': owner['username']}),
        text=True, capture_output=True, check=True, timeout=30)
    value = json.loads(result.stdout)
    if (value.get('schema') != 'o01.private-session-revocation.v1'
            or value.get('user_id') != owner['user_id'] or value.get('revoked') is not True):
        raise ValueError('Fixture session revocation was not verified')


def cookie_jar(client):
    handlers = [h for h in client.handlers if isinstance(h, urllib.request.HTTPCookieProcessor)]
    if len(handlers) != 1:
        raise ValueError('Exactly one private cookie jar required')
    return handlers[0].cookiejar


def expiry_fixture(owner, client):
    cookies = [c for c in cookie_jar(client) if c.name.startswith('wordpress_logged_in_')]
    if len(cookies) != 1:
        raise ValueError('Exactly one owner login cookie required')
    cookie = cookies[0]
    result = subprocess.run(['php', str(Path(__file__).with_name('http-expiry-fixture.php'))],
        input=json.dumps({'user_id': owner['user_id'], 'username': owner['username'],
                         'cookie': urllib.parse.unquote(cookie.value)}),
        text=True, capture_output=True, check=True, timeout=30)
    value = json.loads(result.stdout)
    if (value.get('schema') != 'o01.private-expiry-fixture.v1'
            or value.get('user_id') != owner['user_id']
            or value.get('cookie_name') != cookie.name
            or value.get('expired_cookie_verified') is not True
            or value.get('expired_nonce_verified') is not True
            or any(not isinstance(value.get(k), str) or not value[k]
                   or any(c in value[k] for c in '\r\n')
                   for k in ('expired_cookie', 'expired_nonce', 'fresh_nonce'))):
        raise ValueError('Unverified private expiration fixture')
    return value, cookie


def run(base, fixture, context):
    count = 0

    def check(condition, label):
        nonlocal count
        if not condition:
            raise AssertionError(label)
        count += 1
        print('PASS ' + label)

    endpoint = base + '/index.php?rest_route=/o01-acceptance/v1/handoff'
    html = '<!doctype html>\r\n<html><head><style>body{color:#123}</style></head><body>Eric’s café</body></html>\n'
    package = {'schema': 'peoplerun.o01.local_full_html_approval.v1',
               'authority': 'LOCAL_ONLY_NOT_HOST_RECEIPT', 'publication_authorized': False,
               'revision': 1, 'draft': [], 'approved_full_html': html,
               'full_html_sha256': hashlib.sha256(html.encode()).hexdigest()}
    payload = {'package': package, 'project_id': fixture['project_id'],
               'expected_version': 0, 'request_key': 'http_request_' + fixture['tag']}

    def post(client, value, nonce=None, *, rejected=False):
        before = database_snapshot(fixture['project_id']) if rejected else None
        headers = {'Content-Type': 'application/json'}
        if nonce is not None:
            headers['X-WP-Nonce'] = nonce
        status, body = request(client, endpoint, json.dumps(value).encode(), headers)
        if rejected:
            after = database_snapshot(fixture['project_id'])
            check(before == after, 'denied HTTP attempt leaves project rows, revisions and version unchanged')
        return status, json.loads(body)

    anonymous = session(base, context)
    status, body = post(anonymous, payload, rejected=True)
    check(status == 401 and body.get('code') == 'authentication_required', 'anonymous HTTP request rejected')
    bad = session(base, context)
    check(login(bad, base, fixture['owner'], 'incorrect-' + fixture['tag']) is None,
          'wrong password does not establish an authenticated nonce session')
    owner = session(base, context)
    nonce = login(owner, base, fixture['owner'])
    check(isinstance(nonce, str) and bool(nonce), 'real login cookie obtains REST nonce through authenticated AJAX')
    status, body = post(owner, payload, 'invalid', rejected=True)
    check(status == 403 and body.get('code') == 'rest_cookie_invalid_nonce', 'WordPress rejects invalid REST nonce')
    status, body = post(owner, payload, rejected=True)
    check(status == 401 and body.get('code') == 'authentication_required', 'login cookie without REST nonce rejected')
    status, saved = post(owner, payload, nonce)
    check(status == 200 and saved.get('result') == 'REVISION_SAVED_CANDIDATE'
          and type(saved.get('revision_id')) is int and saved['revision_id'] > 0,
          'cookie plus nonce saves a real revision through HTTP')
    check(saved.get('content_sha256') == package['full_html_sha256'], 'HTTP result preserves approved content fingerprint')
    check(all(saved.get(k) is False for k in ('approval_verified', 'payment_verified', 'published', 'publication_authorized')),
          'HTTP handoff grants no approval payment or publishing authority')
    status, replay = post(owner, payload, nonce)
    check(status == 200 and replay.get('revision_id') == saved['revision_id'], 'HTTP replay returns the same revision')
    changed = copy.deepcopy(payload)
    changed['package']['approved_full_html'] += 'changed'
    changed['package']['full_html_sha256'] = hashlib.sha256(changed['package']['approved_full_html'].encode()).hexdigest()
    status, body = post(owner, changed, nonce, rejected=True)
    check(status == 403 and body.get('result') == 'DENIED', 'changed-content HTTP replay rejected')
    stale = copy.deepcopy(payload)
    stale['request_key'] += '_stale'
    status, body = post(owner, stale, nonce, rejected=True)
    check(status == 403 and body.get('result') == 'DENIED', 'HTTP stale version rejected')
    other = session(base, context)
    other_nonce = login(other, base, fixture['other'])
    check(isinstance(other_nonce, str) and bool(other_nonce), 'second real user login established')
    foreign_nonce_payload = copy.deepcopy(payload)
    foreign_nonce_payload['expected_version'] = 1
    foreign_nonce_payload['request_key'] += '_foreign_nonce'
    status, body = post(owner, foreign_nonce_payload, other_nonce, rejected=True)
    check(status == 403 and body.get('code') == 'rest_cookie_invalid_nonce',
          'another user REST nonce cannot authorize the owner cookie session')
    second_owner = session(base, context)
    second_owner_nonce = login(second_owner, base, fixture['owner'])
    check(isinstance(second_owner_nonce, str) and bool(second_owner_nonce)
          and second_owner_nonce != nonce,
          'independent owner login obtains a distinct session-bound nonce')
    session_nonce_payload = copy.deepcopy(payload)
    session_nonce_payload['expected_version'] = 1
    session_nonce_payload['request_key'] += '_different_session_nonce'
    status, body = post(owner, session_nonce_payload, second_owner_nonce, rejected=True)
    check(status == 403 and body.get('code') == 'rest_cookie_invalid_nonce',
          'same owner nonce from another login session rejected')
    other_payload = copy.deepcopy(payload)
    other_payload['expected_version'] = 1
    other_payload['request_key'] += '_other'
    status, body = post(other, other_payload, other_nonce, rejected=True)
    check(status == 403 and body.get('reason') == 'ownership_required', 'other logged-in owner cannot write this project')
    aged, original_cookie = expiry_fixture(fixture['owner'], owner)
    expired_nonce_payload = copy.deepcopy(payload)
    expired_nonce_payload['expected_version'] = 1
    expired_nonce_payload['request_key'] += '_expired_nonce'
    status, body = post(owner, expired_nonce_payload, aged['expired_nonce'], rejected=True)
    check(status == 403 and body.get('code') == 'rest_cookie_invalid_nonce',
          'correctly signed out-of-window nonce rejected with active owner session')
    expired_owner = session(base, context)
    expired_cookie = copy.copy(original_cookie)
    expired_cookie.value = aged['expired_cookie']
    # Deliver expired SIGNED CONTENT to the server; do not let client expiry drop it.
    expired_cookie.expires = None
    expired_cookie.discard = True
    cookie_jar(expired_owner).set_cookie(expired_cookie)
    expired_cookie_payload = copy.deepcopy(payload)
    expired_cookie_payload['expected_version'] = 1
    expired_cookie_payload['request_key'] += '_expired_cookie'
    status, body = post(expired_owner, expired_cookie_payload, aged['fresh_nonce'], rejected=True)
    check((status, body.get('code')) in ((401, 'authentication_required'),
          (403, 'rest_cookie_invalid_nonce')),
          'correctly signed cookie expired beyond POST grace cannot write')
    revoke_fixture_session(fixture['owner'])
    revoked_payload = copy.deepcopy(payload)
    revoked_payload['expected_version'] = 1
    revoked_payload['request_key'] += '_revoked_session'
    status, body = post(owner, revoked_payload, nonce, rejected=True)
    check((status, body.get('code')) in ((401, 'authentication_required'),
          (403, 'rest_cookie_invalid_nonce')),
          'formerly valid cookie and nonce rejected after server-side session revocation')
    print(f'{count} real HTTPS checks passed; natural expiry and multiworker races remain separate')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--fixture', required=True)
    parser.add_argument('--ca-file', help='CA certificate for the disposable local TLS server')
    args = parser.parse_args()
    base = validate_base(args.base_url)
    fixture = json.loads(Path(args.fixture).read_text())
    if fixture.get('schema') != 'o01.disposable.http-fixture.v1':
        raise ValueError('Unexpected fixture schema')
    run(base, fixture, ssl.create_default_context(cafile=args.ca_file))


if __name__ == '__main__':
    main()
