<?php
declare(strict_types=1);
// Private CLI observer only. Never register this as an HTTP endpoint.
if (PHP_SAPI !== 'cli' || getenv('O01_DISPOSABLE_ACCEPTANCE') !== 'YES') { exit(2); }
$root = getenv('O01_WP_ROOT');
if (!$root || !is_file($root.'/wp-load.php')) { throw new RuntimeException('Disposable WordPress required'); }
require $root.'/wp-load.php';
global $wpdb;
if (DB_NAME !== 'o01_ephemeral' || $wpdb->prefix !== 'o01_acceptance_'
    || !in_array(DB_HOST, ['localhost','127.0.0.1','127.0.0.1:3306'], true)
    || home_url() !== 'https://127.0.0.1:8443') {
    throw new RuntimeException('Refusing non-disposable database');
}
$input = json_decode(stream_get_contents(STDIN), true, 16, JSON_THROW_ON_ERROR);
$pid = $input['project_id'] ?? null;
if (!is_int($pid) || $pid < 1) { throw new RuntimeException('Positive project ID required'); }
// Query raw rows, bypassing object caches. Stable order includes duplicate meta rows.
$posts = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->posts} WHERE ID=%d OR post_parent=%d ORDER BY ID", $pid, $pid), ARRAY_A);
if ($wpdb->last_error !== '') { throw new RuntimeException('Post snapshot query failed'); }
if (!is_array($posts) || count(array_filter($posts, static fn($r) => (int)$r['ID'] === $pid && $r['post_type'] === 'pr_iw_project')) !== 1) {
    throw new RuntimeException('Fixture project not found');
}
$meta = $wpdb->get_results($wpdb->prepare(
    "SELECT m.* FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID=m.post_id WHERE p.ID=%d OR p.post_parent=%d ORDER BY m.meta_id", $pid, $pid), ARRAY_A);
if ($wpdb->last_error !== '' || !is_array($meta)) { throw new RuntimeException('Meta snapshot query failed'); }
$versions = array_values(array_map(static fn($r) => $r['meta_value'], array_filter($meta,
    static fn($r) => (int)$r['post_id'] === $pid && $r['meta_key'] === '_pr_iw_version')));
if (count($versions) !== 1) { throw new RuntimeException('Ambiguous project version'); }
echo json_encode(['schema'=>'o01.private-db-snapshot.v1', 'project_id'=>$pid,
    'revision_count'=>count(array_filter($posts, static fn($r) => $r['post_type'] === 'pr_iw_revision')),
    'version'=>$versions[0], 'rows_sha256'=>hash('sha256', json_encode([$posts,$meta], JSON_THROW_ON_ERROR))], JSON_THROW_ON_ERROR)."\n";
