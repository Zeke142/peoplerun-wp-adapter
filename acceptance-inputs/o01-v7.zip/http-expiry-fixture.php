<?php
declare(strict_types=1);
// Private CLI expiry fixture control only. Never expose over HTTP.
if (PHP_SAPI !== 'cli' || getenv('O01_DISPOSABLE_ACCEPTANCE') !== 'YES') { exit(2); }
$root = getenv('O01_WP_ROOT');
if (!$root || !is_file($root.'/wp-load.php')) { throw new RuntimeException('Disposable WordPress required'); }
require $root.'/wp-load.php';
global $wpdb;
if (DB_NAME !== 'o01_ephemeral' || $wpdb->prefix !== 'o01_acceptance_'
    || !in_array(DB_HOST, ['localhost','127.0.0.1','127.0.0.1:3306'], true)
    || home_url() !== 'https://127.0.0.1:8443') {
    throw new RuntimeException('Refusing non-disposable database');
}
$input = json_decode(stream_get_contents(STDIN), true, 16, JSON_THROW_ON_ERROR);
$uid = $input['user_id'] ?? null;
$name = $input['username'] ?? null;
$cookie = $input['cookie'] ?? null;
if (!is_int($uid) || $uid < 1 || !is_string($name)
    || !preg_match('/\Ao01_http_owner_[a-f0-9]{16}\z/D', $name)
    || !is_string($cookie) || strlen($cookie) > 4096) {
    throw new RuntimeException('Disposable HTTP fixture owner/cookie required');
}
$user = get_user_by('id', $uid);
if (!$user || $user->user_login !== $name) { throw new RuntimeException('Fixture identity mismatch'); }
$_SERVER['REQUEST_METHOD'] = 'POST';
$parts = wp_parse_auth_cookie($cookie, 'logged_in');
if (!$parts || $parts['username'] !== $name || wp_validate_auth_cookie($cookie, 'logged_in') !== $uid) {
    throw new RuntimeException('Original cookie is not currently valid for fixture owner');
}
$token = $parts['token'];
if (!WP_Session_Tokens::get_instance($uid)->verify($token)) { throw new RuntimeException('Original session is inactive'); }
$_COOKIE[LOGGED_IN_COOKIE] = $cookie;
wp_set_current_user($uid);
$fresh = wp_create_nonce('wp_rest');
if (!wp_verify_nonce($fresh, 'wp_rest')) { throw new RuntimeException('Positive nonce control failed'); }
// Signed with the actual fixture session, but outside both accepted nonce ticks.
$tick = wp_nonce_tick('wp_rest') - 3;
$oldNonce = substr(wp_hash($tick.'|wp_rest|'.$uid.'|'.$token, 'nonce'), -12, 10);
if (wp_verify_nonce($oldNonce, 'wp_rest') !== false) { throw new RuntimeException('Aged nonce is unexpectedly valid'); }
// Signed expiration is over two hours old: beyond WordPress POST/AJAX grace.
$expires = time() - 2 * HOUR_IN_SECONDS - 60;
$oldCookie = wp_generate_auth_cookie($uid, $expires, 'logged_in', $token);
$expiredEvent = false;
add_action('auth_cookie_expired', static function () use (&$expiredEvent): void { $expiredEvent = true; });
if (wp_validate_auth_cookie($oldCookie, 'logged_in') !== false || !$expiredEvent
    || !WP_Session_Tokens::get_instance($uid)->verify($token)) {
    throw new RuntimeException('Signed expired cookie control failed');
}
// Sensitive stdout is captured privately by the client, never uploaded or logged.
echo json_encode(['schema'=>'o01.private-expiry-fixture.v1', 'user_id'=>$uid,
    'cookie_name'=>LOGGED_IN_COOKIE, 'expired_cookie'=>$oldCookie,
    'expired_nonce'=>$oldNonce, 'fresh_nonce'=>$fresh,
    'expired_cookie_verified'=>true, 'expired_nonce_verified'=>true], JSON_THROW_ON_ERROR)."\n";
