<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli' || getenv('O01_DISPOSABLE_ACCEPTANCE')!=='YES') { exit(2); }
$root=getenv('O01_WP_ROOT');
if(!$root || !is_file($root.'/wp-load.php'))throw new RuntimeException('Local WordPress required');
require $root.'/wp-load.php';
global $wpdb;
if(DB_NAME!=='o01_ephemeral' || $wpdb->prefix!=='o01_acceptance_'
    || !in_array(DB_HOST,['localhost','127.0.0.1','127.0.0.1:3306'],true)
    || !in_array(parse_url(home_url(),PHP_URL_HOST),['localhost','127.0.0.1'],true)) {
    throw new RuntimeException('Refusing non-disposable configuration');
}
if(!function_exists('pr_iw_g1_v2_create_project'))throw new RuntimeException('Disposable HTTP plugin not loaded');
if(($argv[1]??'')!=='setup')throw new RuntimeException('Usage: php http-fixture.php setup');
$tag=bin2hex(random_bytes(8)); $users=[];
foreach(['owner','other'] as $role) {
    $username='o01_http_'.$role.'_'.$tag; $password=bin2hex(random_bytes(24));
    $uid=wp_create_user($username,$password);
    if(is_wp_error($uid))throw new RuntimeException('Fixture user creation failed; discard disposable database');
    $users[$role]=['username'=>$username,'password'=>$password,'user_id'=>(int)$uid];
}
wp_set_current_user($users['owner']['user_id']);
$project=pr_iw_g1_v2_create_project($users['owner']['user_id'],'HTTP acceptance '.$tag,'http_project_'.$tag);
if(is_wp_error($project))throw new RuntimeException('Fixture project creation failed; discard disposable database');
wp_set_current_user(0);
// Write stdout directly to a private local file; never upload fixture credentials.
echo json_encode(['schema'=>'o01.disposable.http-fixture.v1','tag'=>$tag,'project_id'=>$project['project_id'],
    'owner'=>$users['owner'],'other'=>$users['other']],JSON_THROW_ON_ERROR)."\n";
