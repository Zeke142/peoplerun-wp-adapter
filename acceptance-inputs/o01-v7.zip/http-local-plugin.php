<?php
/** Disposable loopback HTTP acceptance plugin. Never install on production. */
declare(strict_types=1);
if (!defined('ABSPATH') || getenv('O01_DISPOSABLE_ACCEPTANCE') !== 'YES') { return; }
global $wpdb;
if (DB_NAME !== 'o01_ephemeral' || $wpdb->prefix !== 'o01_acceptance_'
    || !in_array(DB_HOST, ['localhost','127.0.0.1','127.0.0.1:3306'], true)
    || !in_array(parse_url(home_url(), PHP_URL_HOST), ['localhost','127.0.0.1'], true)) { return; }
$harness = getenv('O01_HARNESS_ROOT');
if (!$harness || !is_file($harness.'/O01WordPressStudioAdapter.php')) { return; }
if (function_exists('pr_iw_g1_v2_add_revision')) { return; }
require_once $harness.'/g1-host-source.php';
require_once $harness.'/O01WordPressStudioAdapter.php';
// admin-ajax authenticates the real WordPress cookie without needing a REST nonce first.
add_action('wp_ajax_o01_acceptance_nonce', static function (): void {
    if (!is_ssl()) { wp_send_json_error(['reason'=>'https_required'], 403); }
    nocache_headers();
    wp_send_json_success(['nonce'=>wp_create_nonce('wp_rest')]);
});
add_action('rest_api_init', static function (): void {
    register_rest_route('o01-acceptance/v1', '/handoff', [
        'methods'=>'POST',
        'permission_callback'=>static function () {
            return is_user_logged_in() ? true : new WP_Error('authentication_required', 'Login required', ['status'=>401]);
        },
        'callback'=>static function (WP_REST_Request $request) {
            $in=$request->get_json_params();
            if (!is_array($in) || !is_array($in['package']??null)
                || !is_int($in['project_id']??null) || !is_int($in['expected_version']??null)
                || !is_string($in['request_key']??null)) {
                return new WP_Error('invalid_input', 'Invalid test request', ['status'=>400]);
            }
            $result=O01WordPressStudioAdapter::receive($in['package'],$in['project_id'],
                $in['expected_version'],$in['request_key'],$request);
            return new WP_REST_Response($result,($result['result']??'')==='REVISION_SAVED_CANDIDATE'?200:403);
        },
    ]);
});
