<?php
declare(strict_types=1);
// Private CLI fixture control only. Never expose over HTTP.
if (PHP_SAPI !== 'cli' || getenv('O01_DISPOSABLE_ACCEPTANCE') !== 'YES') { exit(2); }
$root = getenv('O01_WP_ROOT');
if (!$root || !is_file($root.'/wp-load.php')) { throw new RuntimeException('Disposable WordPress required'); }
require $root.'/wp-load.php';
global $wpdb;
if (DB_NAME !== 'o01_ephemeral' || $wpdb->prefix !== 'o01_acceptance_'
    || !in_array(DB_HOST, ['localhost','127.0.0.1','127.0.0.1:3306'], true)
    || home_url() !== 'https://127.0.0.1:8443') {
    throw new RuntimeException('Refusing non-disposable database');
}
$input = json_decode(stream_get_contents(STDIN), true, 16, JSON_THROW_ON_ERROR);
$uid = $input['user_id'] ?? null;
$name = $input['username'] ?? null;
if (!is_int($uid) || $uid < 1 || !is_string($name)
    || !preg_match('/\Ao01_http_owner_[a-f0-9]{16}\z/D', $name)) {
    throw new RuntimeException('Disposable HTTP fixture owner required');
}
$user = get_user_by('id', $uid);
if (!$user || $user->user_login !== $name) { throw new RuntimeException('Fixture identity mismatch'); }
$manager = WP_Session_Tokens::get_instance($uid);
if (count($manager->get_all()) < 1) { throw new RuntimeException('No active session to revoke'); }
$manager->destroy_all();
if (count($manager->get_all()) !== 0) { throw new RuntimeException('Session revocation not verified'); }
echo json_encode(['schema'=>'o01.private-session-revocation.v1','user_id'=>$uid,'revoked'=>true], JSON_THROW_ON_ERROR)."\n";
