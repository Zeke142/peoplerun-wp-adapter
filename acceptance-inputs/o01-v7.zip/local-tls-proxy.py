#!/usr/bin/env python3
"""Disposable loopback TLS termination; no remote targets or verification bypass."""
import argparse
import http.client
import http.server
import ssl

HOP = {'connection', 'transfer-encoding', 'keep-alive', 'proxy-authenticate',
       'proxy-authorization', 'te', 'trailer', 'upgrade'}

def make_handler(port):
    class Proxy(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # URLs, cookies and credentials never enter launcher logs.

        def do_GET(self):
            self.forward()

        def do_POST(self):
            self.forward()

        def forward(self):
            if self.path.startswith(('http:', 'https:', '//')):
                self.send_error(400)
                return
            length = self.headers.get('Content-Length', '0')
            if not length.isdecimal() or int(length) > 1500000 or self.headers.get('Transfer-Encoding'):
                self.send_error(400)
                return
            body = self.rfile.read(int(length))
            headers = {k: v for k, v in self.headers.items()
                       if k.lower() not in HOP | {'host', 'x-forwarded-proto'}}
            headers['Host'] = '127.0.0.1:8443'
            conn = http.client.HTTPConnection('127.0.0.1', port, timeout=20)
            try:
                conn.request(self.command, self.path, body, headers)
                response = conn.getresponse()
                data = response.read()
                self.send_response(response.status)
                for key, value in response.getheaders():
                    if key.lower() not in HOP | {'content-length'}:
                        self.send_header(key, value)
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except (OSError, http.client.HTTPException):
                self.send_error(502)
            finally:
                conn.close()
    return Proxy

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cert', required=True)
    parser.add_argument('--key', required=True)
    args = parser.parse_args()
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 8443), make_handler(8765))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(args.cert, args.key)
    server.socket = context.wrap_socket(server.socket, server_side=True)
    server.serve_forever()

if __name__ == '__main__':
    main()
