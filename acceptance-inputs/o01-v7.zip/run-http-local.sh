#!/usr/bin/env bash
# Run only against an ALREADY PREPARED disposable local WordPress/MySQL.
set -euo pipefail
umask 077
test "${O01_DISPOSABLE_ACCEPTANCE:-}" = YES
: "${O01_WP_ROOT:?Set the disposable WordPress absolute root}"
for tool in php python3 openssl; do command -v "$tool" >/dev/null || { echo "Missing runtime: $tool" >&2; exit 2; }; done
harness_dir=$(cd -- "$(dirname -- "$0")" && pwd)
export O01_HARNESS_ROOT="$harness_dir"
# No writes until the real configuration is checked.
php -r 'require getenv("O01_WP_ROOT")."/wp-load.php"; global $wpdb;
if (DB_NAME!=="o01_ephemeral" || $wpdb->prefix!=="o01_acceptance_" ||
 !in_array(DB_HOST,["127.0.0.1","127.0.0.1:3306","localhost"],true) ||
 home_url()!=="https://127.0.0.1:8443") exit(2);'
test -d "$O01_WP_ROOT/wp-content/mu-plugins"
test ! -e "$O01_WP_ROOT/wp-content/mu-plugins/o01-local-acceptance.php"
test ! -e "$O01_WP_ROOT/o01-local-router.php"
private_dir=$(mktemp -d)
php_pid=''; tls_pid=''; plugin_owned=0; router_owned=0
cleanup() {
  if test -n "$tls_pid"; then kill "$tls_pid" 2>/dev/null || true; wait "$tls_pid" 2>/dev/null || true; fi
  if test -n "$php_pid"; then kill "$php_pid" 2>/dev/null || true; wait "$php_pid" 2>/dev/null || true; fi
  if test "$plugin_owned" = 1; then rm -f -- "$O01_WP_ROOT/wp-content/mu-plugins/o01-local-acceptance.php"; fi
  if test "$router_owned" = 1; then rm -f -- "$O01_WP_ROOT/o01-local-router.php"; fi
  rm -rf -- "$private_dir"
}
trap cleanup EXIT
# Refuse occupied ports rather than send fixture credentials to an existing service.
python3 - <<'PY'
import socket
for port in (8443,8765):
    with socket.socket() as s:
        s.bind(('127.0.0.1',port))
PY
openssl req -x509 -newkey rsa:2048 -nodes -days 1 \
  -keyout "$private_dir/key.pem" -out "$private_dir/cert.pem" \
  -subj /CN=127.0.0.1 -addext subjectAltName=IP:127.0.0.1 \
  -addext basicConstraints=critical,CA:TRUE >"$private_dir/tls-setup.log" 2>&1
# Run non-HTTP suites before loading the HTTP fixture plugin.
php "$harness_dir/acceptance.php"
php "$harness_dir/concurrency.php"
cp -- "$harness_dir/http-local-plugin.php" "$O01_WP_ROOT/wp-content/mu-plugins/o01-local-acceptance.php"
plugin_owned=1
cat >"$O01_WP_ROOT/o01-local-router.php" <<'PHP'
<?php
// Dedicated backend behind our loopback TLS terminator only.
if (($_SERVER['REMOTE_ADDR']??'')!=='127.0.0.1' || ($_SERVER['HTTP_HOST']??'')!=='127.0.0.1:8443') { http_response_code(403); exit; }
$_SERVER['HTTPS']='on';
$_SERVER['SERVER_PORT']='8443';
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if (is_string($path) && preg_match('~\.(?:css|js|png|jpg|gif|ico|woff2?)$~i',$path)) { return false; }
if (is_string($path) && preg_match('~\A/(?:wp-login\.php|wp-admin/admin-ajax\.php)\z~D',$path)) { require __DIR__.$path; return; }
require __DIR__.'/index.php';
PHP
router_owned=1
php "$harness_dir/http-fixture.php" setup >"$private_dir/fixture.json"
php -S 127.0.0.1:8765 -t "$O01_WP_ROOT" "$O01_WP_ROOT/o01-local-router.php" >"$private_dir/php.log" 2>&1 &
php_pid=$!
python3 "$harness_dir/local-tls-proxy.py" --cert "$private_dir/cert.pem" --key "$private_dir/key.pem" >"$private_dir/proxy.log" 2>&1 &
tls_pid=$!
python3 - "$private_dir/cert.pem" <<'PY'
import ssl,sys,time,urllib.request,urllib.error
ctx=ssl.create_default_context(cafile=sys.argv[1])
for attempt in range(30):
    try:
        urllib.request.urlopen('https://127.0.0.1:8443/wp-login.php',context=ctx,timeout=1).close()
        break
    except (OSError,urllib.error.URLError):
        time.sleep(.2)
else:
    raise SystemExit('Local HTTPS startup failed')
PY
kill -0 "$php_pid"; kill -0 "$tls_pid"
python3 "$harness_dir/http-acceptance.py" --base-url https://127.0.0.1:8443 \
  --ca-file "$private_dir/cert.pem" --fixture "$private_dir/fixture.json"
echo 'Disposable integration suites completed; discard the entire disposable database.'
