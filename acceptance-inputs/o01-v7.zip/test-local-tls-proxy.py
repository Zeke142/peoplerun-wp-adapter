#!/usr/bin/env python3
"""Local transport smoke tests only: no WordPress or database proof."""
import http.server
import importlib.util
import pathlib
import ssl
import subprocess
import tempfile
import threading
import urllib.error
import urllib.request

spec=importlib.util.spec_from_file_location('proxy',pathlib.Path(__file__).with_name('local-tls-proxy.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class Backend(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_POST(self):
        data=self.rfile.read(int(self.headers['Content-Length']))
        self.send_response(200)
        self.send_header('Set-Cookie','transport_probe=ok; Secure; HttpOnly')
        self.end_headers()
        self.wfile.write(self.headers['Host'].encode()+b'|'+self.headers['X-WP-Nonce'].encode()+b'|'+data)

with tempfile.TemporaryDirectory() as tmp:
    cert=tmp+'/cert.pem';key=tmp+'/key.pem'
    subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-keyout',key,'-out',cert,
      '-subj','/CN=127.0.0.1','-addext','subjectAltName=IP:127.0.0.1','-addext','basicConstraints=critical,CA:TRUE'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    backend=http.server.ThreadingHTTPServer(('127.0.0.1',0),Backend)
    proxy=http.server.ThreadingHTTPServer(('127.0.0.1',0),module.make_handler(backend.server_port))
    tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);tls.load_cert_chain(cert,key)
    proxy.socket=tls.wrap_socket(proxy.socket,server_side=True)
    for server in [backend,proxy]: threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        url=f'https://127.0.0.1:{proxy.server_port}/probe'
        context=ssl.create_default_context(cafile=cert)
        req=urllib.request.Request(url,data=b'full\r\npage',headers={'X-WP-Nonce':'transport-only'})
        with urllib.request.urlopen(req,context=context,timeout=5) as r:
            assert r.read()==b'127.0.0.1:8443|transport-only|full\r\npage'
            print('PASS validated TLS forwards exact body and nonce header')
            assert r.headers['Set-Cookie']=='transport_probe=ok; Secure; HttpOnly'
            print('PASS secure cookie response preserved')
        try:
            urllib.request.urlopen(req,context=ssl.create_default_context(),timeout=5)
            raise AssertionError('Untrusted certificate accepted')
        except urllib.error.URLError as e:
            assert isinstance(e.reason,ssl.SSLCertVerificationError)
            print('PASS untrusted certificate rejected')
        req=urllib.request.Request(url,data=b'x',headers={'Content-Length':'1500001'})
        try:
            urllib.request.urlopen(req,context=context,timeout=5)
            raise AssertionError('Oversize accepted')
        except urllib.error.HTTPError as e:
            assert e.code==400
            print('PASS excessive request length rejected')
        print('4 local TLS transport checks passed; WordPress/MySQL not exercised')
    finally:
        for server in [proxy,backend]: server.shutdown();server.server_close()
