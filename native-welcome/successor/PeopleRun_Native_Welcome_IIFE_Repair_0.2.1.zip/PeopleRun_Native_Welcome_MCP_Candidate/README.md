# PeopleRun AI — Native Welcome MCP Candidate 0.1.0

LOCAL ENGINEERING CANDIDATE ONLY. Not installed, connected to ChatGPT, publicly shared, submitted, or deployed.

## Reused verified assets

- `reference/accepted-blue-menu.html` — exact 6,254-byte original, SHA-256 `29a80f8c2efb21f565c4accabd5cd131e5fbedaede288ebe0c527d040d816b39`.
- `public/welcome-widget.html` — derived mobile-first interface, preserving five colored panels and styling, with three added local functioning choices.
- Public welcome rules copied conceptually from installed `peoplerun-public-welcome` v0.1.0; no private workspace tools or host actions.

## Local MCP contract

- `POST /mcp`: JSON-RPC calls: `initialize`, `tools/list`, `resources/list`, `resources/read`, `tools/call`, `ping`. Notifications return HTTP 202.
- `show_people_run_welcome`: read-only, advertises `_meta.ui.resourceUri` and compatibility `_meta['openai/outputTemplate']` pointing to `ui://peoplerun/welcome-blue-v1.html`.
- `choose_people_run_welcome({choice:'explore'|'start'|'sample'})`: public conversational demonstration only; returns `persisted:false`, `executed:false`.
- `resources/read` delivers HTML with MIME `text/html;profile=mcp-app`.
- Runtime binds **127.0.0.1 only**; no paid dependencies or external credentials; no writes, WordPress, CBS, O01, G3, or production access.

## Test

`npm test` runs Node built-in 21-test suite; `npm start` starts localhost-only endpoint if needed.

## Boundaries

- Handwritten minimal JSON-RPC/MCP implementation, not an official MCP SDK; protocol conformance against MCP Inspector and full Streamable HTTP session/negotiation remains unverified.
- All three widget buttons work as **local content switches**. There is **no initialized MCP Apps iframe bridge**; ChatGPT-native widget mounting and host-to-tool interactions have not been validated.
- A live ChatGPT connection, iPhone rendering, plugin packaging, public distribution/review, OAuth, and keyword-triggered activation are NOT verified. No automatic invocation on typing `PeopleRun.ai` is promised.
- Local HTTP endpoint is intentionally unavailable to remote ChatGPT. For later opt-in testing, use a separately authorized, supported isolated HTTPS MCP endpoint with verified $0 hard stop and protected network boundaries.
- Browser standalone widget controls are self-contained, not server calls. The MCP choice tools are separately exercised in integration tests.
