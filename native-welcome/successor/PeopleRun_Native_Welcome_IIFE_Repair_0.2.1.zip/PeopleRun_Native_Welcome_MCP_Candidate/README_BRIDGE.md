# PeopleRun Native Welcome — Isolated MCP SDK Bridge Candidate v0.2.0

## Integrity and scope
- Original v0.1.0 ZIP hash: `45867cd1a997f3b4f84775cc9946cf6379152f46fe1fb70b06fd3ebe75494682`.
- Immutable approved reference: `reference/accepted-blue-menu.html` (6254 bytes; SHA-256 `29a80f8c2efb21f565c4accabd5cd131e5fbedaede288ebe0c527d040d816b39`).
- This v0.2.0 is standalone source only; not a ChatGPT plugin, installed connector, or released service.

## Implementation
- `sdk/server.mjs`: **official MCP SDK imports**; uses stdio, `McpServer`, `registerTool`, `registerResource` and Zod validation; UI uses `text/html;profile=mcp-app`. A missing built UI fails closed.
- `bridge/bridge-client.mjs`: **official MCP Apps SDK import**; connects to host with `App.connect()`, subscribes before connect, and uses `App.callServerTool` for `explore`, `start`, and `sample`. Only safe, conversation-only text is returned.
- `scripts/build-widget.mjs`: uses esbuild to bundle ext-apps into the single self-contained HTML resource, without CDN/network fetches at runtime.
- `public/welcome-widget.html`: approved blue design and five colored panels, with bridge insertion marker.

## Tests performed
- 21/21 baseline v0.1.0 tests passed on the untouched unzipped original.
- 15/15 v0.2.0 bridge-source tests passed with a **simulated** host, including 3/3 tool invocation paths, unavailable-host rejection, server-error handling, privacy/static-source assertions.
- Node syntax checked for server and bridge client.
- Official SDK runtime, real handshake, actual package bundling, MCP Inspector, iframe integration, and iPhone ChatGPT **NOT TESTED**. npm registry inaccessible (`EAI_AGAIN`), dependencies not cached. Do **not** call this host-integrated or release-ready.

## Controlled next gate
In a separate authorized $0-capable environment with official npm packages available: `npm ci` (after lockfile generation and audit), `npm run build:widget`, `node --test tests/bridge.test.mjs`, then run actual SDK client↔server and Apps host↔iframe integration and inspect results. No public deploy or plugin replacement without separate authorization.

## Stop boundaries
Never access CBS, WordPress, O01, G3, payments, credentials, private workspace, or customer records from this public candidate. Never claim arbitrary user typing `PeopleRun.ai` invokes the plugin automatically.

**Note:** Legacy v0.1.0 `tests/contract.test.mjs` are included as historical references. They assert the old standalone script structure and are not applicable to the new bridged template; run them only against the original untouched v0.1.0 archive. `npm test` runs the new bridge-specific suite.
