# Native Welcome IIFE compatibility repair

Derived from pinned v0.2.0 ZIP. Two source file changes only: `bridge/bridge-client.mjs` moves await for `app.connect()` into a callable async function, and `tests/bridge.test.mjs` adds one regression guard. Blue HTML is unchanged.

Run: `node --test tests/bridge.test.mjs` and `node --check bridge/bridge-client.mjs`. For **actual** compile use the previously established GitHub npm-capable isolated runner with `npm run build:widget`; no such run or GitHub commit is authorized by this local repair.
