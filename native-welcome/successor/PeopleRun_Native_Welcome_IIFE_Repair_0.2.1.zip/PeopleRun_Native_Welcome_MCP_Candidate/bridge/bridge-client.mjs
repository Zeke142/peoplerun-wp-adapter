// Intended for bundling into widget HTML with official @modelcontextprotocol/ext-apps.
// Never loads CDN assets or crosses production origin. SDK npm install required.
import { App } from '@modelcontextprotocol/ext-apps';
const app = new App({name:'PeopleRun Welcome',version:'0.2.0'});
const output=document.getElementById('choice-result');
const choices=new Set(['explore','start','sample']);
let connected=false;
function render(obj){
 if(!obj||typeof obj!=='object')return;
 output.replaceChildren();
 const label=document.createElement('strong'); label.textContent=obj.title||'PeopleRun';
 const detail=document.createElement('p');detail.textContent=obj.detail||'';
 const next=document.createElement('p');next.textContent=obj.next||'';
 output.append(label,detail,next);output.hidden=false;
}
app.ontoolresult=params=>{if(params?.structuredContent)render(params.structuredContent);};
app.ontoolinput=params=>{};
document.querySelectorAll('[data-choice]').forEach(button=>button.addEventListener('click',async()=>{
 const choice=button.dataset.choice;if(!choices.has(choice))return;
 if(!connected){render({title:'Connection unavailable',detail:'This menu needs a compatible MCP Apps host. No action was run.'});return;}
 button.disabled=true;
 try{
  const result=await app.callServerTool({name:'choose_people_run_welcome',arguments:{choice}});
  if(result?.isError)throw new Error('Server denied request');
  render(result?.structuredContent||{});
 }catch(e){render({title:'Choice unavailable',detail:'No work was saved or executed.'});}
 finally{button.disabled=false;}
}));
async function connectBridge(){try{await app.connect();connected=true;}catch{render({title:'Connection unavailable',detail:'No action was run.'});}}
void connectBridge();
