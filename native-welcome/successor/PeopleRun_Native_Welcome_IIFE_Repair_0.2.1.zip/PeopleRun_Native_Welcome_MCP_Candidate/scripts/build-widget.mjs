import {build} from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const {outputFiles}=await build({entryPoints:[path.join(root,'bridge/bridge-client.mjs')],bundle:true,format:'iife',platform:'browser',write:false,legalComments:'none',target:'es2022'});
let template=fs.readFileSync(path.join(root,'public/welcome-widget.html'),'utf8');
if(!template.includes('<!-- MCP_APPS_BRIDGE_BUNDLE -->'))throw new Error('Missing safe bridge insertion marker');
const js=outputFiles[0].text;
// Inline bundled SDK so MCP resource is self-contained. Never use remote CDN.
template=template.replace('<!-- MCP_APPS_BRIDGE_BUNDLE -->','<script type="module">'+js.replaceAll('</script','<\/script')+'</script>');
fs.mkdirSync(path.join(root,'dist'),{recursive:true});
fs.writeFileSync(path.join(root,'dist/welcome-widget.html'),template);
console.log('Offline bundled MCP Apps view:',Buffer.byteLength(template),'bytes');
