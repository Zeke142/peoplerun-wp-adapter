// Official SDK implementation candidate. Not run when npm dependencies are absent.
// Local-only: stdio, no public listener, no host writes.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { McpServer, ResourceTemplate } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
const root=path.dirname(fileURLToPath(import.meta.url));
const built=path.join(root,'../dist/welcome-widget.html');
if(!fs.existsSync(built))throw new Error('STOP: official MCP Apps widget not bundled; run npm install and npm run build:widget locally first');
const html=fs.readFileSync(built,'utf8');
const URI='ui://peoplerun/welcome-blue-v1.html';
const choices=Object.freeze({
 explore:{title:'Explore PeopleRun',detail:'Five panels: Proof, Blocker, Progress & Shelf, Protected State, and Deterministic Next. Six stages: Discover, Define, Build, Verify, Deliver, ARC END.',next:'Choose Start with My Idea.'},
 start:{title:'Start with My Idea',detail:'What is your goal in one sentence? This is a conversation-only draft; nothing is saved or executed.',next:'Describe your goal in one sentence.'},
 sample:{title:'Sample WorkCard — fictional bakery',detail:'Proof: no verified business details. Blocker: owner-approved hours and copy missing. Progress: Discover. Protected: no publication or private operations.',next:'Obtain an approved service description.'}
});
const response=obj=>({content:[{type:'text',text:JSON.stringify(obj)}],structuredContent:obj});
const server=new McpServer({name:'peoplerun-native-welcome-isolated',version:'0.2.0'});
server.registerResource('people-run-blue-menu',URI,{mimeType:'text/html;profile=mcp-app'},async()=>({contents:[{uri:URI,mimeType:'text/html;profile=mcp-app',text:html}]}));
server.registerTool('show_people_run_welcome',{
 title:'Show PeopleRun AI public welcome',description:'Show isolated blue five-panel public welcome only; no private operations.',
 inputSchema:{},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false},
 _meta:{ui:{resourceUri:URI},'openai/outputTemplate':URI}
},async()=>response({title:'PeopleRun AI',choices:Object.keys(choices),mode:'PUBLIC_DEMO_ONLY',persisted:false,executed:false}));
server.registerTool('choose_people_run_welcome',{
 title:'Choose PeopleRun welcome action',description:'Return one harmless public welcome example.',
 inputSchema:{choice:z.enum(['explore','start','sample'])},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}
},async({choice})=>response({...choices[choice],choice,mode:'PUBLIC_DEMO_ONLY',persisted:false,executed:false}));
await server.connect(new StdioServerTransport());
