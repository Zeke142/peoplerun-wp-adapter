import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const widget=fs.readFileSync(path.join(root,'public','welcome-widget.html'),'utf8');
const URI='ui://peoplerun/welcome-blue-v1.html';
const CHOICES=['explore','start','sample'];
const TOOLS=[{
 name:'show_people_run_welcome',description:'Show PeopleRun AI public blue five-panel welcome menu. Public, static, conversation-only demonstration; no private host connection.',
 inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false},
 _meta:{ui:{resourceUri:URI},'openai/outputTemplate':URI,'openai/widgetDescription':'A blue welcome menu with five colored panels and three demo choices.'}
},{name:'choose_people_run_welcome',description:'Resolve one public welcome choice without persisting anything: explore, start, or sample.',
 inputSchema:{type:'object',properties:{choice:{type:'string',enum:CHOICES}},required:['choice'],additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}}];
const actions={
 explore:{title:'Explore PeopleRun',detail:'PeopleRun organizes a goal into Proof, Blocker, Progress & Shelf, Protected State, and Deterministic Next through Discover, Define, Build, Verify, Deliver, ARC END.',next:'Choose Start with My Idea to draft a work packet.'},
 start:{title:'Start with My Idea',detail:'What is your goal in one sentence? We can prepare a conversation-only draft WorkCard. No job is saved or executed.',next:'Describe your goal in one sentence.'},
 sample:{title:'Sample WorkCard (fictional)',detail:'Proof: a bakery wants an informational webpage, with no independent details verified. Blocker: approved business hours and wording are missing. Progress & Shelf: Discover stage only. Protected State: no private data or publication. Deterministic Next: obtain the owner-approved service description.',next:'Ask for a conversation-only draft after owner approval.'}
};
const content=(obj)=>({content:[{type:'text',text:JSON.stringify(obj)}],structuredContent:obj});
function dispatch(req){
 const {method,params={},id}=req;
 const success=result=>({jsonrpc:'2.0',id,result});
 const failure=(code,message)=>({jsonrpc:'2.0',id,error:{code,message}});
 if(method==='initialize')return success({protocolVersion:'2025-06-18',capabilities:{tools:{listChanged:false},resources:{listChanged:false}},serverInfo:{name:'peoplerun-native-welcome-local-candidate',version:'0.1.0'}});
 if(method==='ping')return success({});
 if(method==='tools/list')return success({tools:TOOLS});
 if(method==='resources/list')return success({resources:[{uri:URI,name:'PeopleRun blue welcome interface',mimeType:'text/html;profile=mcp-app'}]});
 if(method==='resources/read')return params.uri===URI?success({contents:[{uri:URI,mimeType:'text/html;profile=mcp-app',text:widget}]}):failure(-32602,'Unknown resource');
 if(method==='tools/call'){
   if(params.name==='show_people_run_welcome'){
     if(params.arguments && Object.keys(params.arguments).length)return failure(-32602,'No arguments allowed');
     return success({...content({title:'PeopleRun AI',stages:['Discover','Define','Build','Verify','Deliver','ARC END'],panels:['Proof','Blocker','Progress & Shelf','Protected State','Deterministic Next'],choices:CHOICES,mode:'PUBLIC_DEMO_ONLY'}),_meta:{ui:{resourceUri:URI},'openai/outputTemplate':URI}});
   }
   if(params.name==='choose_people_run_welcome'){
     const args=params.arguments;
     if(!args||typeof args!=='object'||Array.isArray(args)||Object.keys(args).length!==1||!CHOICES.includes(args.choice))return failure(-32602,'Invalid choice');
     return success(content({...actions[args.choice],choice:args.choice,mode:'PUBLIC_DEMO_ONLY',persisted:false,executed:false}));
   }
   return failure(-32602,'Unknown tool');
 }
 return failure(-32601,'Method not found');
}
export function createServer(){return http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');
 res.setHeader('Access-Control-Allow-Origin','*');
 res.setHeader('Access-Control-Allow-Methods','POST, GET, OPTIONS');
 res.setHeader('Access-Control-Allow-Headers','content-type,mcp-protocol-version,mcp-session-id,accept');
 if(req.method==='OPTIONS'&&req.url==='/mcp'){res.writeHead(204);return res.end();}
 if(req.url==='/'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'text/plain'});return res.end('PeopleRun native welcome LOCAL candidate only');}
 if(req.url!=='/mcp'){res.writeHead(404);return res.end();}
 if(req.method!=='POST'){res.writeHead(405,{'Allow':'POST, OPTIONS'});return res.end();}
 let raw='';try{for await(const chunk of req){raw+=chunk;if(raw.length>65536)throw new Error('Too large');}}catch{res.writeHead(413);return res.end();}
 let payload;try{payload=JSON.parse(raw);}catch{res.writeHead(400,{'Content-Type':'application/json'});return res.end(JSON.stringify({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Parse error'}}));}
 if(!payload||typeof payload!=='object'||Array.isArray(payload)||payload.jsonrpc!=='2.0'||typeof payload.method!=='string'){res.writeHead(400);return res.end();}
 if(payload.id===undefined){res.writeHead(202);return res.end();}
 const result=dispatch(payload);res.writeHead(200,{'Content-Type':'application/json','MCP-Protocol-Version':'2025-06-18'});res.end(JSON.stringify(result));
});}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const host='127.0.0.1';const port=Number(process.env.PORT||3000);createServer().listen(port,host,()=>console.log(`LOCAL ONLY http://${host}:${port}/mcp`));
}
