import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const root=path.resolve(import.meta.dirname,'..');
const bridge=fs.readFileSync(path.join(root,'bridge/bridge-client.mjs'),'utf8');
const sdk=fs.readFileSync(path.join(root,'sdk/server.mjs'),'utf8');
const html=fs.readFileSync(path.join(root,'public/welcome-widget.html'),'utf8');
function harness({connectFail=false,toolFail=false}={}){
 const calls=[];const buttons={};const status={hidden:true,children:[],replaceChildren(){this.children=[]},append(...items){this.children.push(...items)}};
 for(const choice of ['explore','start','sample'])buttons[choice]={dataset:{choice},disabled:false,addEventListener(_,fn){this.click=fn}};
 const document={querySelectorAll:()=>Object.values(buttons),getElementById:()=>status,createElement:()=>({textContent:''})};
 class App{constructor(){this.ontoolresult=null;this.ontoolinput=null;}async connect(){if(connectFail)throw Error('disabled')}async callServerTool({name,arguments:args}){calls.push({name,args});if(toolFail)throw Error('denied');return {structuredContent:{title:'Choice: '+args.choice,detail:'Public demo',next:'No execution'}}}}
 const source=bridge.replace(/^import .*?;\s*/m,'');
 const execute=new Function('App','document','return (async()=>{'+source+'})()');
 return {ready:execute(App,document),buttons,calls,status};
}
test('SDK bridge source imports official ext-apps App',()=>assert.match(bridge,/from '@modelcontextprotocol\/ext-apps'/));
test('SDK server imports official MCP server and stdio',()=>{assert.match(sdk,/from '@modelcontextprotocol\/sdk\/server\/mcp.js'/);assert.match(sdk,/StdioServerTransport/)});
test('SDK server fail-closed on missing bundle',()=>assert.match(sdk,/STOP: official MCP Apps widget not bundled/));
test('SDK source serves MCP Apps mime and UI resource URI',()=>{assert.match(sdk,/text\/html;profile=mcp-app/);assert.match(sdk,/ui:\/\/peoplerun\/welcome-blue-v1.html/)});
test('UI tool metadata declares resource URI',()=>{assert.match(sdk,/'openai\/outputTemplate'/);assert.match(sdk,/resourceUri:URI/)});
test('HTML preserved five distinct panels and six phases',()=>{for(const phrase of ['Proof','Blocker','Progress &amp; Shelf','Protected State','Deterministic Next','Discover','Define','Build','Verify','Deliver','ARC END'])assert.ok(html.includes(phrase),phrase)});
test('approved exact reference untouched',async()=>{const crypto=await import('node:crypto');const source=fs.readFileSync(path.join(root,'reference/accepted-blue-menu.html'));assert.equal(source.length,6254);assert.equal(crypto.createHash('sha256').update(source).digest('hex'),'29a80f8c2efb21f565c4accabd5cd131e5fbedaede288ebe0c527d040d816b39')});
test('template is inline-bundle only: no CDN, no external script',()=>{assert.match(html,/MCP_APPS_BRIDGE_BUNDLE/);assert.doesNotMatch(html,/<script[^>]*src=/i);assert.doesNotMatch(html,/https?:\/\//)});
for(const choice of ['explore','start','sample'])test(`simulated host choice ${choice} invokes exact tool`,async()=>{const h=harness();await h.ready;await h.buttons[choice].click();assert.deepEqual(h.calls,[{name:'choose_people_run_welcome',args:{choice}}]);assert.equal(h.buttons[choice].disabled,false);assert.equal(h.status.hidden,false);assert.match(h.status.children[0].textContent,/Choice/)});
test('simulated host connection failure denies calls',async()=>{const h=harness({connectFail:true});await h.ready;await h.buttons.explore.click();assert.equal(h.calls.length,0);assert.match(h.status.children[0].textContent,/unavailable/)});
test('simulated server error no action and re-enables button',async()=>{const h=harness({toolFail:true});await h.ready;await h.buttons.start.click();assert.equal(h.calls.length,1);assert.equal(h.buttons.start.disabled,false);assert.match(h.status.children[1].textContent,/No work/)});
test('SDK server contains no network listener / private host access',()=>{assert.doesNotMatch(sdk,/createServer\(|\.listen\(|fetch\(|child_process|exec\(/);assert.match(sdk,/StdioServerTransport/)});
test('bundle marker present exactly once',()=>assert.equal(html.split('<!-- MCP_APPS_BRIDGE_BUNDLE -->').length,2));

// Prevent recurrence of the IIFE-incompatible top-level await seen in Actions run 40068393364.
test('widget bridge has no top-level await; connect is inside async function',()=>{
 assert.match(bridge,/async function connectBridge\(\)/);
 assert.match(bridge,/void connectBridge\(\)/);
 assert.doesNotMatch(bridge,/^try\{await app\.connect\(\)/m);
});
