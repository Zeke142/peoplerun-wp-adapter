# DN57 · Populated synthetic intake → exact PHP render → local review

**PASS (bounded):** Synthetic DN54 intake admitted with explicit synthetic customer-intake evidence, DN55 adapter called real PHP final renderer, final-review.html hashed and verified, receipt linked to exact intake SHA-256, revision, slug, design, language and proposed URL. Placeholder phone remains excluded. No customer approval or publishing authority.

**Browser test:** Chromium could launch but navigation to file:// and localhost was blocked by environment policy. Used `page.set_content` with a *test-only deterministic SHA oracle* to test the browser controls, imported intake, file selection, review display, edit invalidation and failed re-verification. This is **not** browser cryptographic acceptance. Real cryptographic checks are independently performed in Python. No physical-iPhone test.

**Usage:** `python -m unittest test_dn57 test_dn56 -v`, `python verify_dn57.py .`, `python test_browser.py` (test-only hash oracle). Open `Genuine_Intake_on_iPhone.html` in a secure JavaScript-capable browser; import `synthetic_intake.json`, `final-review.html`, `review-receipt.json` in its review section. Browser verifies HTML and intake digests when WebCrypto is available. Edits invalidate local review; regeneration is required. Do not confuse synthetic facts labeled verified in the fixture with genuine verification of a real customer.

**Important limits:** Browser does not independently validate DN54 evidence authenticity, DN55 receipt signature, customer identity, offer, payment, public route or expiry. Receipt integrity is verified by Python and is unkeyed; it is not a trusted signature. DN51 credential STOP, $0, CBS/G3/HOLD and Master Save preserved. No host or GitHub changes.
