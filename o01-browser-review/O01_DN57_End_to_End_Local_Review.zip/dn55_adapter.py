"""Strict DN54 -> DN22 exact renderer, source-only, no publication or offer authority."""
import json, hashlib, pathlib, subprocess, tempfile
from intake_gate import admit, IntakeDenied, FIELDS, digest

class RenderDenied(ValueError):pass

def build(packet, out):
    handoff=admit(packet)
    facts=handoff['verified_public_facts']
    # A non-customer demo cannot become a customer review page by renaming its state.
    if not facts.get('business_name'):
        raise RenderDenied('verified_business_name_required')
    for key in ('phone','address','hours'):
        value=facts.get(key,'')
        if '555-01' in value or value.strip().lower() in ('7 am – midnight','7 am - midnight'):
            raise RenderDenied('placeholder_fact_denied')
    if packet['design']!='blue':
        raise RenderDenied('unsupported_style_requires_review')
    if packet['language']!='en':
        raise RenderDenied('unsupported_language_requires_review')
    if packet['proposed_term']!='undecided':
        # Term preference may be captured, but never treated as a paid contract.
        pass
    if not isinstance(out,pathlib.Path):out=pathlib.Path(out)
    out.mkdir(parents=True,exist_ok=True)
    source={k:handoff[k] for k in ('proposed_slug','review_revision','verified_public_facts','review_only_fields')}
    source['schema']='peoplerun.o01.dn55.render-input.v1'
    with tempfile.TemporaryDirectory() as tmp:
        inp=pathlib.Path(tmp)/'input.json';inp.write_text(json.dumps(source,ensure_ascii=False),encoding='utf8')
        run=subprocess.run(['php',str(pathlib.Path(__file__).with_name('final_render.php')),str(inp),str(out)],capture_output=True,text=True)
    if run.returncode:raise RenderDenied('php_renderer_denied:'+run.stderr.strip()[:120])
    render=json.loads(run.stdout)
    html=(out/'final-review.html').read_bytes()
    if hashlib.sha256(html).hexdigest()!=render['render_sha256']:raise RenderDenied('render_readback_denied')
    receipt={'schema':'peoplerun.o01.dn55.local-review.v1','status':'UNAPPROVED_LOCAL_REVIEW','source_intake_sha256':handoff['intake_sha256'],'review_revision':handoff['review_revision'],'proposed_slug':handoff['proposed_slug'],'proposed_url':handoff['proposed_url'],'url_reserved':False,'design':handoff['design'],'language':handoff['language'],'term_preference':handoff['term_preference'],'render_sha256':render['render_sha256'],'html_bytes':len(html),'renderer':'o01-dn17-exact-v1','excluded_fields':sorted(set(FIELDS)-set(facts)),'verified_public_fields':sorted(facts),'customer_approval':None,'offer':None,'price':None,'payment':None,'publication_authorized':False,'dn24_approval_scope_issued':False}
    receipt['receipt_sha256']=digest(receipt)
    (out/'review-receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding='utf8')
    return receipt
