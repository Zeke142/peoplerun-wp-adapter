<?php
declare(strict_types=1);
require_once __DIR__.'/o01-core.php';
if(PHP_SAPI!=='cli'||count($argv)!==3){fwrite(STDERR,"usage: php final_render.php input.json output-dir\n");exit(2);}
try {
 $d=json_decode((string)file_get_contents($argv[1]),true,512,JSON_THROW_ON_ERROR);
 if(($d['schema']??null)!=='peoplerun.o01.dn55.render-input.v1')throw new DomainException('schema_denied');
 $v=$d['verified_public_facts']??null;
 if(!is_array($v)||!is_array($d['review_only_fields']??null)||!is_string($d['proposed_slug']??null))throw new DomainException('invalid_fields');
 $esc=static fn($s)=>htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
 $name=$v['business_name']??null;
 if(!is_string($name)||trim($name)==='')throw new DomainException('verified_business_name_required');
 $pieces=['<section class="o01-theme-blue"><h1>'.$esc($name).'</h1>'];
 foreach(['business_type'=>'Service','description'=>'About','hours'=>'Hours','address'=>'Address','city'=>'Area','phone'=>'Phone','website'=>'Website'] as $k=>$label){
  if(isset($v[$k])&&is_string($v[$k])&&trim($v[$k])!=='')$pieces[]='<p><strong>'.$label.':</strong> '.$esc($v[$k]).'</p>';
 }
 $pieces[]='</section>';
 $p=['customer_id'=>'LOCAL_REVIEW_ONLY_NOT_CUSTOMER','offer_id'=>'LOCAL_REVIEW_ONLY_NOT_OFFER','price_cents'=>1,'currency'=>'USD','page_count'=>1,'term'=>'1_week','privacy'=>'public','slug'=>$d['proposed_slug'],'revision'=>$d['review_revision'],'expires_at_utc'=>'2099-01-01T00:00:00Z','sanitized_html'=>implode('',$pieces),'css'=>O01_DN17_CSS,'asset_manifest'=>[]];
 // Required publisher fields above are inert technical sentinels, NOT a customer offer.
 $html=o01_render($p);$dir=$argv[2];if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException('mkdir_denied');
 file_put_contents($dir.'/final-review.html',$html,LOCK_EX);
 echo json_encode(['render_sha256'=>hash('sha256',$html),'html_bytes'=>strlen($html),'template'=>'o01-dn17-exact-v1','technical_sentinels_not_offer'=>true],JSON_THROW_ON_ERROR);
}catch(Throwable $e){fwrite(STDERR,'DENIED: '.$e->getMessage()."\n");exit(1);}
