"""DN54 customer-fact admission (offline). Generates inert preview inputs only.

No claims of customer consent, public authenticity, payment, URL reservation or publish.
This is NOT the publisher's final render; DN24 must still render/verify post intake.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib, json, re

VALID_ORIGINS={'customer_supplied','public_source','unverified','missing'}
FIELDS=('business_name','business_type','description','phone','address','city','hours','website','logo_asset')
SLUG_RE=re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
URL_RE=re.compile(r'^https://[^\s<>"\']+$')
PHONE_RE=re.compile(r'^\+?[\d ()+.\-]{7,30}$')
class IntakeDenied(ValueError):pass

def require(flag,code):
    if not flag:raise IntakeDenied(code)

def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def slugify(name):
    name=re.sub(r'[^a-z0-9]+','-',name.strip().lower()).strip('-')
    require(bool(name) and len(name)<=80 and SLUG_RE.fullmatch(name),'slug_denied')
    return name

def normalize_field(key,record):
    require(type(record) is dict,'field_not_object')
    require(set(record)=={'value','origin','evidence','verified'},'field_schema_denied')
    value, origin, evidence, verified=(record[x] for x in ('value','origin','evidence','verified'))
    require(type(value) is str and len(value)<=600 and type(origin) is str and origin in VALID_ORIGINS,'field_value_denied')
    require(type(evidence) is str and len(evidence)<=350 and type(verified) is bool,'field_evidence_denied')
    value=value.strip()
    if origin=='missing':require(not value and not evidence and not verified,'missing_invariant_denied')
    else:require(bool(value),'empty_value_denied')
    if origin=='unverified':require(not verified,'unverified_claim_denied')
    if origin=='public_source':require(evidence.startswith('https://') and URL_RE.fullmatch(evidence),'public_source_evidence_required')
    if origin=='customer_supplied':require(evidence.startswith('customer-intake:') or not evidence,'customer_evidence_denied')
    if verified:require(origin in ('customer_supplied','public_source') and bool(evidence),'verification_evidence_denied')
    if key=='phone' and value:require(PHONE_RE.fullmatch(value),'phone_denied')
    if key=='website' and value:require(URL_RE.fullmatch(value),'website_denied')
    return {'value':value,'origin':origin,'evidence':evidence,'verified':verified}

def admit(packet):
    require(type(packet) is dict and packet.get('schema')=='peoplerun.o01.dn54.customer-intake.v1','schema_denied')
    require(set(packet)=={'schema','fields','design','language','page_count','proposed_term','proposed_slug','review_revision'},'packet_schema_denied')
    fields=packet['fields'];require(type(fields) is dict and set(fields)==set(FIELDS),'fields_denied')
    norm={k:normalize_field(k,fields[k]) for k in FIELDS}
    require(packet['design'] in ('blue','warm','green') and packet['language'] in ('en','es','zh'),'design_denied')
    require(type(packet['page_count']) is int and packet['page_count']==1,'dn24_one_page_only')
    require(packet['proposed_term'] in ('undecided','1_week','1_month','1_year'),'term_denied')
    rev=packet['review_revision'];require(type(rev) is int and rev>=1,'revision_denied')
    name=norm['business_name']
    require(name['value'] and name['origin']!='missing','business_name_required')
    slug=slugify(name['value'])
    require(packet['proposed_slug']==slug,'slug_mismatch')
    # Never count a customer-supplied claim as verified customer identity/authority.
    outstanding=[k for k,v in norm.items() if v['origin'] in ('missing','unverified') or not v['verified']]
    # Avoid exporting placeholders as known facts; 555-number pattern is never verified here.
    for key in ('phone','hours','address'):
        r=norm[key]
        if r['value'] and r['origin']=='unverified':require(not r['verified'],'placeholder_denied')
    result={'schema':'peoplerun.o01.dn54.review-handoff.v1',
            'business_name':name['value'], 'proposed_slug':slug,
            'proposed_url':f'https://peoplerun.ai/{slug}/',
            'source_route_candidate':f'https://peoplerun.ai/?o01_dn22_page={slug}',
            'design':packet['design'],'language':packet['language'],
            'page_count':1,'term_preference':packet['proposed_term'],'review_revision':rev,
            'verified_public_facts':{k:v['value'] for k,v in norm.items() if v['verified']},
            'review_only_fields':{k:v['value'] for k,v in norm.items() if v['value'] and not v['verified']},
            'missing_or_unverified':outstanding,
            'render_status':'REQUIRES_INDEPENDENT_DN24_FINAL_RENDER',
            'authority':'UNVERIFIED','customer_approval':None,'price':None,
            'payment':None,'reservation_created':False,'publish_authorized':False}
    result['intake_sha256']=digest(packet)
    result['handoff_sha256']=digest(result)
    return result
