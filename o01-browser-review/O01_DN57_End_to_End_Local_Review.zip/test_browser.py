import pathlib,json,threading,http.server,socketserver
from playwright.sync_api import sync_playwright
P=pathlib.Path(__file__).parent
def run():
 with sync_playwright() as pw:
  b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=b.new_page()
  # Browser interaction test only: injected SHA oracle; real hashes verified independently by Python.
  import hashlib
  raw=(P/'final-review.html').read_bytes(); intake=(P/'synthetic_intake.json').read_text()
  from intake_gate import digest
  known={raw.decode('utf8'):hashlib.sha256(raw).hexdigest(),json.dumps(json.loads(intake),sort_keys=True,separators=(',',':'),ensure_ascii=False):digest(json.loads(intake))}
  page.set_content((P/'Genuine_Intake_on_iPhone.html').read_text(),wait_until='load')
  page.evaluate('''known=>{const m=new Map(Object.entries(known));Object.defineProperty(window,'crypto',{configurable:true,value:{subtle:{digest:async(_alg,b)=>{const text=new TextDecoder().decode(b);const hex=m.get(text)||'0'.repeat(64);return new Uint8Array(hex.match(/../g).map(x=>parseInt(x,16))).buffer}}}})}''',known)
  page.locator('#intakeFile').set_input_files(str(P/'synthetic_intake.json'))
  page.locator('#renderFile').set_input_files(str(P/'final-review.html'))
  page.locator('#receiptFile').set_input_files(str(P/'review-receipt.json'))
  page.locator('#verifyRender').click()
  page.wait_for_timeout(250)
  ok=page.locator('#renderStatus').inner_text()
  assert 'RENDER HASH MATCH' in ok,ok
  assert page.locator('#copyReviewReceipt').is_enabled()
  assert page.locator('#exactFrame').is_visible()
  page.locator('#business_name').fill('Edited business')
  assert not page.locator('#copyReviewReceipt').is_enabled()
  assert not page.locator('#exactFrame').is_visible()
  page.locator('#verifyRender').click()
  page.wait_for_timeout(250)
  assert 'REVIEW DENIED' in page.locator('#renderStatus').inner_text()
  print('BROWSER PASS: imported populated intake + exact rendered digest + edit invalidation + reverify denied')
  b.close()
if __name__=='__main__':run()
