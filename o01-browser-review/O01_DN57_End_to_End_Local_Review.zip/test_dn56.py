import unittest,tempfile,shutil,json,pathlib
from verify_dn56 import verify,ReviewDenied
ROOT=pathlib.Path(__file__).parent
class Tests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.p=pathlib.Path(self.t.name)
  for n in ('final-review.html','review-receipt.json'):shutil.copy2(ROOT/n,self.p/n)
 def test_good(self):self.assertEqual(verify(self.p)['status'],'LOCAL_RENDER_VERIFIED_NOT_APPROVED')
 def test_changed_html(self):
  (self.p/'final-review.html').write_bytes(b'changed')
  with self.assertRaises(ReviewDenied):verify(self.p)
 def test_changed_receipt(self):
  r=json.loads((self.p/'review-receipt.json').read_text());r['review_revision']=2;(self.p/'review-receipt.json').write_text(json.dumps(r))
  with self.assertRaises(ReviewDenied):verify(self.p)
 def test_authority_denials(self):
  for key,val in [('url_reserved',True),('publication_authorized',True),('customer_approval','yes'),('offer',{}),('price',1),('payment','paid'),('dn24_approval_scope_issued',True)]:
   with self.subTest(key=key):
    r=json.loads((ROOT/'review-receipt.json').read_text());r[key]=val;(self.p/'review-receipt.json').write_text(json.dumps(r))
    with self.assertRaises(ReviewDenied):verify(self.p)
 def test_missing_authority_field(self):
  r=json.loads((self.p/'review-receipt.json').read_text());del r['customer_approval'];(self.p/'review-receipt.json').write_text(json.dumps(r))
  with self.assertRaises(ReviewDenied):verify(self.p)
 def test_wrong_schema(self):
  r=json.loads((self.p/'review-receipt.json').read_text());r['schema']='other';(self.p/'review-receipt.json').write_text(json.dumps(r))
  with self.assertRaises(ReviewDenied):verify(self.p)
if __name__=='__main__':unittest.main()
