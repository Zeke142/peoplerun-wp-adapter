import unittest,tempfile,shutil,json,pathlib
from verify_dn57 import verify_handoff,ReviewDenied
ROOT=pathlib.Path(__file__).parent
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=pathlib.Path(self.tmp.name)
  for f in ['synthetic_intake.json','final-review.html','review-receipt.json']:shutil.copy2(ROOT/f,self.p/f)
 def test_handoff(self):self.assertEqual(verify_handoff(self.p)['status'],'SYNTHETIC_LOCAL_HANDOFF_VERIFIED_NOT_CUSTOMER_APPROVED')
 def test_intake_tamper(self):
  r=json.loads((self.p/'synthetic_intake.json').read_text());r['fields']['business_name']['value']='Changed';(self.p/'synthetic_intake.json').write_text(json.dumps(r))
  with self.assertRaises((ReviewDenied,ValueError)):verify_handoff(self.p)
 def test_html_tamper(self):
  (self.p/'final-review.html').write_text('tamper')
  with self.assertRaises(ReviewDenied):verify_handoff(self.p)
 def test_receipt_tamper(self):
  r=json.loads((self.p/'review-receipt.json').read_text());r['source_intake_sha256']='0'*64;(self.p/'review-receipt.json').write_text(json.dumps(r))
  with self.assertRaises(ReviewDenied):verify_handoff(self.p)
 def test_approval_denials(self):
  for key,val in [('publication_authorized',True),('customer_approval','yes'),('price',123),('payment','paid'),('url_reserved',True)]:
   with self.subTest(key=key):
    r=json.loads((ROOT/'review-receipt.json').read_text());r[key]=val;(self.p/'review-receipt.json').write_text(json.dumps(r))
    with self.assertRaises(ReviewDenied):verify_handoff(self.p)
if __name__=='__main__':unittest.main()
