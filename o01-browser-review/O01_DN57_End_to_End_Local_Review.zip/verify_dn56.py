"""Independent fail-closed DN56 review bundle check. No consent or publish authority."""
import json,hashlib,pathlib,sys
from intake_gate import digest
class ReviewDenied(ValueError):pass
def verify(folder):
 folder=pathlib.Path(folder)
 receipt=json.loads((folder/'review-receipt.json').read_text())
 html=(folder/'final-review.html').read_bytes()
 if receipt.get('schema')!='peoplerun.o01.dn55.local-review.v1' or receipt.get('status')!='UNAPPROVED_LOCAL_REVIEW':raise ReviewDenied('wrong_receipt')
 if receipt.get('render_sha256')!=hashlib.sha256(html).hexdigest() or receipt.get('html_bytes')!=len(html):raise ReviewDenied('render_mismatch')
 for k,v in {'url_reserved':False,'publication_authorized':False,'dn24_approval_scope_issued':False,'customer_approval':None,'offer':None,'price':None,'payment':None}.items():
  if k not in receipt or receipt[k]!=v:raise ReviewDenied('authority_denied_'+k)
 if receipt.get('receipt_sha256')!=digest({k:v for k,v in receipt.items() if k!='receipt_sha256'}):raise ReviewDenied('receipt_tamper')
 if receipt.get('renderer')!='o01-dn17-exact-v1' or receipt.get('design')!='blue' or receipt.get('language')!='en':raise ReviewDenied('unsupported_render')
 return {'status':'LOCAL_RENDER_VERIFIED_NOT_APPROVED','render_sha256':receipt['render_sha256'],'review_revision':receipt['review_revision'],'proposed_slug':receipt['proposed_slug'],'publication_authorized':False,'customer_approval':None}
if __name__=='__main__':
 print(json.dumps(verify(sys.argv[1] if len(sys.argv)>1 else '.'),indent=2))
