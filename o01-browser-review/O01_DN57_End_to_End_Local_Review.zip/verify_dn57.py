import json,pathlib,hashlib
from intake_gate import admit
from verify_dn56 import verify,ReviewDenied
def verify_handoff(folder):
 folder=pathlib.Path(folder)
 packet=json.loads((folder/'synthetic_intake.json').read_text())
 admitted=admit(packet)
 receipt=json.loads((folder/'review-receipt.json').read_text())
 result=verify(folder)
 if receipt['source_intake_sha256']!=admitted['intake_sha256']:raise ReviewDenied('intake_digest_mismatch')
 for key,other in [('proposed_slug','proposed_slug'),('review_revision','review_revision'),('design','design'),('language','language'),('proposed_url','proposed_url')]:
  if receipt[key]!=admitted[other]:raise ReviewDenied('identity_mismatch_'+key)
 if sorted(receipt['verified_public_fields'])!=sorted(admitted['verified_public_facts']):raise ReviewDenied('verified_field_mismatch')
 if '555-0100' in (folder/'final-review.html').read_text():raise ReviewDenied('placeholder_leak')
 return {**result,'status':'SYNTHETIC_LOCAL_HANDOFF_VERIFIED_NOT_CUSTOMER_APPROVED'}
if __name__=='__main__':
 import sys
 print(json.dumps(verify_handoff(sys.argv[1] if len(sys.argv)>1 else '.'),indent=2))
